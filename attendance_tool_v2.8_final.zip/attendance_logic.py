"""
attendance_tool/attendance_logic.py
출퇴근 로직: 주간/야간 근무 패턴 판별 및 출퇴근 시간 결정
"""

from datetime import timedelta
from typing import Dict, Tuple, Optional
from datetime import date
from utils import parse_time_hour
from models import ProcessResult


class AttendanceLogic:
    """출퇴근 시간을 결정하는 로직 클래스"""

    # 주간 근무 판정 기준 시간 (0시 ~ 12시 사이 출근)
    DAY_SHIFT_START_HOUR = 0
    DAY_SHIFT_END_HOUR = 12

    def __init__(self, today_map: Dict, yesterday_map: Dict):
        """
        초기화

        Args:
            today_map: 오늘 출퇴근 데이터 맵
            yesterday_map: 전일 출퇴근 데이터 맵
        """
        self.today_map = today_map
        self.yesterday_map = yesterday_map

    def get_info(self, name: str, data_map: Dict) -> Dict:
        """
        이름으로 출퇴근 정보 조회 (없으면 빈 딕셔너리 반환)

        Args:
            name: 직원 이름
            data_map: 출퇴근 데이터 맵

        Returns:
            dict: {출근시각, 퇴근시각, 출근일자, 퇴근일자}
        """
        return data_map.get(name, {})

    def is_day_shift(self, check_in_time: str, check_in_date: Optional[date]) -> bool:
        """
        주간 근무 여부 판정

        Args:
            check_in_time: 출근 시각 (HH:MM)
            check_in_date: 출근 날짜

        Returns:
            bool: 주간 근무이면 True
        """
        # 출근 시각과 날짜가 있어야 판정 가능
        if not check_in_time or check_in_date is None:
            return False

        # 출근 시각이 0~12시 사이면 주간
        hour = parse_time_hour(check_in_time)
        return self.DAY_SHIFT_START_HOUR <= hour < self.DAY_SHIFT_END_HOUR

    def is_night_shift(self, check_in_date: Optional[date],
                       check_out_date: Optional[date]) -> bool:
        """
        야간 근무 여부 판정 (n일 출근 → n+1일 퇴근)

        Args:
            check_in_date: 출근 날짜
            check_out_date: 퇴근 날짜

        Returns:
            bool: 야간 근무이면 True
        """
        # 출근/퇴근 날짜가 모두 있어야 판정 가능
        if check_in_date is None or check_out_date is None:
            return False

        # 퇴근 날짜가 출근 날짜의 다음 날이면 야간
        return check_out_date == check_in_date + timedelta(days=1)

    def decide_attendance(self, name: str) -> ProcessResult:
        """
        직원의 출근/퇴근 시간을 결정

        Args:
            name: 직원 이름

        Returns:
            ProcessResult: 처리 결과 (출근시각, 퇴근시각, 기준날짜, 패턴)
        """
        # 오늘/전일 데이터 가져오기
        info_today = self.get_info(name, self.today_map)
        info_yesterday = self.get_info(name, self.yesterday_map)

        # 각 데이터 추출
        cin_today = info_today.get("출근시각", "")
        cout_today = info_today.get("퇴근시각", "")
        din_today = info_today.get("출근일자", None)
        dout_today = info_today.get("퇴근일자", None)

        cin_yest = info_yesterday.get("출근시각", "")
        cout_yest = info_yesterday.get("퇴근시각", "")
        din_yest = info_yesterday.get("출근일자", None)
        dout_yest = info_yesterday.get("퇴근일자", None)

        # 기본 기준 날짜 설정 (오늘 우선)
        base_date = din_today or dout_today or din_yest or dout_yest

        # 패턴 분석
        is_day_today = self.is_day_shift(cin_today, din_today)
        is_night_yest = self.is_night_shift(din_yest, dout_yest)

        # === 1) 완전 결근 (모든 기록 없음) ===
        if not (cin_today or cout_today or cin_yest or cout_yest):
            return ProcessResult(
                check_in="",
                check_out="",
                base_date=None,
                pattern="absent"
            )

        # === 2) 오늘 주간 출근이 있는 경우 ===
        if is_day_today:
            # 우선순위: 오늘 퇴근 > 전일 퇴근 (월요일/공휴일 다음)
            checkout = cout_today or cout_yest or ""
            return ProcessResult(
                check_in=cin_today,
                check_out=checkout,
                base_date=din_today,
                pattern="day"
            )

        # === 3) 전일 야간 근무 (전일 출근 → 오늘 퇴근) ===
        if is_night_yest:
            return ProcessResult(
                check_in=cin_yest,
                check_out=cout_yest,
                base_date=din_yest,
                pattern="night"
            )

        # === 4) 오늘 출근 없음 + 전일 퇴근만 있음 (미출근자의 이전 퇴근) ===
        # 중요: 오늘 출근이 없고, 전일에 출근 없이 퇴근만 있는 경우
        if not cin_today and not cin_yest and cout_yest:
            return ProcessResult(
                check_in="",
                check_out=cout_yest,
                base_date=dout_yest,
                pattern="prev_checkout_only"
            )

        # === 5) 오늘 퇴근만 있는 경우 ===
        if cout_today and not cin_today and not cin_yest:
            return ProcessResult(
                check_in="",
                check_out=cout_today,
                base_date=dout_today,
                pattern="checkout_only"
            )

        # === 6) 전일 출근만 있고 오늘 출근/퇴근 모두 없음 (미출근 - 전일 퇴근 사용) ===
        # 중요: 원영범, 신현준 케이스
        # 19일 출근+퇴근 있음, 22일 출근/퇴근 없음 → 19일 퇴근만 사용
        if cin_yest and cout_yest and not cin_today and not cout_today:
            return ProcessResult(
                check_in="",
                check_out=cout_yest,
                base_date=dout_yest,
                pattern="prev_day_with_checkout"
            )

        # === 7) 전일 출근만 있고 퇴근 없는 경우 (야간 아님) ===
        if cin_yest and not cout_yest and not cin_today and not cout_today:
            return ProcessResult(
                check_in="",
                check_out="",
                base_date=None,
                pattern="prev_checkin_only_no_data"
            )

        # === 8) 기타 케이스: 우선순위에 따라 선택 ===
        # 출근: 오늘 > 전일
        # 퇴근: 오늘 > 전일
        cin_final = cin_today or cin_yest
        cout_final = cout_today or cout_yest
        
        # 기준 날짜: 출근일 우선
        if cin_final == cin_today:
            base_date = din_today or dout_today or din_yest or dout_yest
        else:
            base_date = din_yest or dout_yest or din_today or dout_today

        return ProcessResult(
            check_in=cin_final,
            check_out=cout_final,
            base_date=base_date,
            pattern="other"
        )


def decide_io(name: str, today_map: Dict, yest_map: Dict) -> Tuple[str, str, Optional[date]]:
    """
    편의 함수: 출근/퇴근/기준날짜를 튜플로 반환
    (기존 코드와의 호환성을 위해 유지)

    Args:
        name: 직원 이름
        today_map: 오늘 데이터 맵
        yest_map: 전일 데이터 맵

    Returns:
        (출근시각, 퇴근시각, 기준날짜)
    """
    logic = AttendanceLogic(today_map, yest_map)
    result = logic.decide_attendance(name)
    return result.check_in, result.check_out, result.base_date
