"""
COM 기반 엑셀 핸들러 (메모 서식 보존용)
openpyxl의 메모 서식 손실 문제 해결
"""
import os
import sys


class ExcelCOMHandler:
    """
    pywin32를 사용한 Excel COM 핸들러
    메모 서식을 완벽하게 보존
    """
    
    def __init__(self, file_path, logger):
        """
        초기화
        
        Args:
            file_path: 엑셀 파일 경로
            logger: 로거 인스턴스
        """
        self.file_path = os.path.abspath(file_path)
        self.logger = logger
        self.excel = None
        self.workbook = None
        
    def __enter__(self):
        """with 문 지원"""
        self.open()
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        """with 문 종료 시 자동 close"""
        self.close()
        
    def open(self):
        """엑셀 파일 열기"""
        try:
            import win32com.client
            
            self.logger.debug("Excel COM 초기화 중...")
            self.excel = win32com.client.Dispatch("Excel.Application")
            self.excel.Visible = False
            self.excel.DisplayAlerts = False
            
            self.logger.debug(f"파일 열기: {self.file_path}")
            self.workbook = self.excel.Workbooks.Open(self.file_path)
            
            return self
            
        except Exception as e:
            self.logger.error(f"Excel COM 초기화 실패: {str(e)}")
            raise
    
    def copy_last_sheet(self, new_sheet_name):
        """
        마지막 시트를 복사
        메모 서식 완벽 보존!
        
        Args:
            new_sheet_name: 새 시트 이름
        """
        try:
            # 마지막 시트 가져오기
            last_sheet = self.workbook.Worksheets(self.workbook.Worksheets.Count)
            
            self.logger.info(f"시트 복사 시작: '{last_sheet.Name}' → '{new_sheet_name}'")
            
            # 시트 복사 (COM은 메모 서식을 완벽하게 복사함!)
            last_sheet.Copy(After=last_sheet)
            
            # 복사된 시트 (마지막 시트)
            new_sheet = self.workbook.Worksheets(self.workbook.Worksheets.Count)
            new_sheet.Name = new_sheet_name
            
            self.logger.success(f"시트 복사 완료: '{last_sheet.Name}' → '{new_sheet_name}'")
            
            return new_sheet
            
        except Exception as e:
            self.logger.error(f"시트 복사 실패: {str(e)}")
            raise
    
    def clear_ranges(self, sheet, ranges):
        """
        지정된 범위의 셀 값 지우기
        
        Args:
            sheet: COM Sheet 객체
            ranges: 범위 리스트 (예: ["D9:E11", "G9:G11"])
        """
        try:
            cleared_count = 0
            
            for rng in ranges:
                sheet.Range(rng).ClearContents()
                # 범위 내 셀 개수 계산
                cell_count = sheet.Range(rng).Cells.Count
                cleared_count += cell_count
            
            self.logger.info(f"셀 지우기 완료: {cleared_count}개 셀")
            
        except Exception as e:
            self.logger.warning(f"셀 지우기 실패: {str(e)}")
    
    def save(self):
        """파일 저장 (메모 서식 완벽 보존!)"""
        try:
            self.logger.debug(f"파일 저장 중: {self.file_path}")
            self.workbook.Save()
            self.logger.success(f"파일 저장 완료: {self.file_path}")
            
        except Exception as e:
            self.logger.error(f"파일 저장 실패: {str(e)}")
            raise
    
    def close(self):
        """엑셀 파일 닫기"""
        try:
            if self.workbook:
                self.logger.debug("워크북 닫기")
                self.workbook.Close(SaveChanges=False)
                self.workbook = None
            
            if self.excel:
                self.logger.debug("Excel 종료")
                self.excel.Quit()
                self.excel = None
                
        except Exception as e:
            self.logger.warning(f"Excel COM 종료 중 오류 (무시됨): {str(e)}")


def use_com_for_sheet_copy(file_path, new_sheet_name, clear_ranges, logger):
    """
    COM을 사용하여 시트 복사 및 셀 지우기
    메모 서식을 완벽하게 보존
    
    Args:
        file_path: 엑셀 파일 경로
        new_sheet_name: 새 시트 이름
        clear_ranges: 지울 범위 리스트
        logger: 로거
    
    Returns:
        str: 생성된 시트 이름
    """
    try:
        with ExcelCOMHandler(file_path, logger) as handler:
            # 시트 복사 (메모 서식 보존!)
            new_sheet = handler.copy_last_sheet(new_sheet_name)
            
            # 셀 지우기
            handler.clear_ranges(new_sheet, clear_ranges)
            
            # 저장 (메모 서식 보존!)
            handler.save()
        
        return new_sheet_name
        
    except Exception as e:
        logger.error(f"COM 기반 시트 복사 실패: {str(e)}")
        raise
