# 근태 자동 입력 프로그램 설치 및 실행 가이드

## 📋 목차
1. [시스템 요구사항](#시스템-요구사항)
2. [설치 방법](#설치-방법)
3. [실행 방법](#실행-방법)
4. [문제 해결](#문제-해결)
5. [파일 구조](#파일-구조)

---

## 💻 시스템 요구사항

### 필수 요구사항
- **Python**: 3.8 이상
- **운영체제**: Windows, macOS, Linux
- **메모리**: 최소 2GB RAM
- **디스크 공간**: 100MB 이상

### 필수 Python 패키지
```
pandas
openpyxl
xlrd
tkinter (대부분의 Python 설치에 포함)
```

---

## 🔧 설치 방법

### 방법 1: pip를 사용한 설치 (권장)

#### 1단계: Python 설치 확인
```bash
# Windows (명령 프롬프트 또는 PowerShell)
python --version

# macOS/Linux (터미널)
python3 --version
```

Python이 설치되어 있지 않다면 [python.org](https://www.python.org/downloads/)에서 다운로드하세요.

#### 2단계: 필수 패키지 설치
```bash
# Windows
pip install pandas openpyxl xlrd

# macOS/Linux
pip3 install pandas openpyxl xlrd
```

#### 3단계: 프로그램 파일 다운로드
모든 `.py` 파일을 하나의 폴더에 저장합니다.

```
attendance_tool/
├── attendance_logic.py
├── config.py
├── data_processor.py          (또는 data_processor_improved.py)
├── excel_handler.py            (또는 excel_handler_improved.py)
├── gui.py
├── main.py                     (또는 main_improved.py)
├── models.py
├── utils.py
├── exceptions.py               (새 파일)
├── validators.py               (새 파일)
└── logger.py                   (새 파일)
```

### 방법 2: requirements.txt 사용

#### 1단계: requirements.txt 생성
프로젝트 폴더에 `requirements.txt` 파일을 생성하고 다음 내용을 추가합니다:

```
pandas>=1.3.0
openpyxl>=3.0.0
xlrd>=2.0.0
```

#### 2단계: 패키지 일괄 설치
```bash
# Windows
pip install -r requirements.txt

# macOS/Linux
pip3 install -r requirements.txt
```

### 방법 3: 가상 환경 사용 (권장 - 고급)

```bash
# 가상 환경 생성
python -m venv venv

# 가상 환경 활성화
# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate

# 패키지 설치
pip install pandas openpyxl xlrd
```

---

## 🚀 실행 방법

### 기본 실행

#### Windows
```bash
# 명령 프롬프트 또는 PowerShell에서
cd C:\path\to\attendance_tool
python main.py
```

#### macOS/Linux
```bash
# 터미널에서
cd /path/to/attendance_tool
python3 main.py
```

### 개선 버전 실행

```bash
# 개선된 버전 사용 시
python main_improved.py
```

### GUI 프로그램 사용법

1. **프로그램 시작**
   - `python main.py` 실행
   - GUI 창이 열립니다

2. **기준 날짜 입력**
   - 형식: `YYYY-MM-DD` (예: `2024-12-22`)
   - 비워두면 오늘 날짜로 자동 설정

3. **파일 선택**
   - "찾기" 버튼을 클릭하여 각 파일 선택
   - **출퇴근 원시 파일**: 원본 출퇴근 데이터 (.xls 또는 .xlsx)
   - **여주 근태 파일**: 여주 근태표 (.xlsx)
   - **SMC 근태 파일**: SMC 근태표 (.xlsx)

4. **실행**
   - "실행" 버튼 클릭
   - 로그 창에서 진행 상황 확인

5. **결과 확인**
   - 완료 메시지가 표시되면 엑셀 파일 확인
   - 오류가 있다면 로그 창의 내용 확인

---

## 🐛 문제 해결

### 문제 1: "ModuleNotFoundError: No module named 'pandas'"

**원인**: pandas 패키지가 설치되지 않음

**해결**:
```bash
pip install pandas openpyxl xlrd
```

### 문제 2: "FileNotFoundError: [Errno 2] No such file or directory"

**원인**: 파일 경로가 잘못되었거나 파일이 존재하지 않음

**해결**:
1. 파일 경로를 다시 확인
2. 파일이 실제로 해당 위치에 있는지 확인
3. 파일 이름에 특수 문자가 있는지 확인

### 문제 3: "PermissionError: [Errno 13] Permission denied"

**원인**: 
- 파일이 Excel에서 열려 있음
- 파일에 쓰기 권한이 없음

**해결**:
1. Excel에서 해당 파일을 모두 닫기
2. 파일 속성에서 "읽기 전용" 해제
3. 관리자 권한으로 프로그램 실행

### 문제 4: "UnicodeDecodeError"

**원인**: 파일 인코딩 문제

**해결**:
1. 엑셀 파일을 다시 저장 (다른 이름으로 저장)
2. UTF-8 인코딩 확인

### 문제 5: "xlrd.biffh.XLRDError: Excel xlsx file; not supported"

**원인**: xlrd 버전 문제 (.xls와 .xlsx 혼동)

**해결**:
```bash
# xlrd 1.2.0 설치 (.xls 지원)
pip install xlrd==1.2.0

# openpyxl 최신 버전 설치 (.xlsx 지원)
pip install --upgrade openpyxl
```

### 문제 6: GUI 창이 열리지 않음

**원인**: tkinter가 설치되지 않음

**해결**:
```bash
# Ubuntu/Debian
sudo apt-get install python3-tk

# macOS (Homebrew)
brew install python-tk

# Windows: Python 재설치 시 "tcl/tk and IDLE" 옵션 선택
```

### 문제 7: "KeyError: '이름'" 또는 컬럼 관련 오류

**원인**: 원시 데이터 파일의 컬럼명이 `config.py`와 다름

**해결**:
1. `config.py` 파일을 열기
2. `COL_NAME`, `COL_DATE`, `COL_IN_RAW`, `COL_OUT_RAW` 값을 실제 컬럼명과 일치하도록 수정

```python
# config.py 예시
COL_NAME = "'이름'"          # 실제 컬럼명에 맞게 수정
COL_DATE = "'근무일자'"      # 실제 컬럼명에 맞게 수정
```

### 문제 8: 처리 속도가 느림

**원인**: 대량의 데이터 또는 로그 출력

**해결**:
1. 로그 레벨을 INFO 이상으로 설정 (DEBUG 로그 비활성화)
2. 데이터를 분할하여 처리
3. 하드웨어 업그레이드 고려

---

## 📂 파일 구조

### 핵심 파일

#### 1. `main.py` (또는 `main_improved.py`)
- **역할**: 프로그램의 진입점
- **주요 기능**: 
  - GUI 초기화
  - 전체 프로세스 조율
  - 예외 처리

#### 2. `gui.py`
- **역할**: 사용자 인터페이스
- **주요 기능**:
  - 파일 선택 대화상자
  - 날짜 입력
  - 로그 출력
  - 실행 버튼

#### 3. `data_processor.py` (또는 `data_processor_improved.py`)
- **역할**: 원시 데이터 처리
- **주요 기능**:
  - 엑셀 파일 읽기
  - 날짜별 데이터 분리
  - 출퇴근 맵 생성

#### 4. `excel_handler.py` (또는 `excel_handler_improved.py`)
- **역할**: 엑셀 파일 조작
- **주요 기능**:
  - 시트 복사
  - 셀 값 쓰기
  - 범위 지우기

#### 5. `attendance_logic.py`
- **역할**: 출퇴근 로직
- **주요 기능**:
  - 주간/야간 근무 판별
  - 출퇴근 시간 결정

#### 6. `config.py`
- **역할**: 설정 관리
- **주요 내용**:
  - 셀 범위 정의
  - 컬럼명 정의
  - 날짜 형식

#### 7. `models.py`
- **역할**: 데이터 모델
- **주요 내용**:
  - AttendanceRecord
  - ProcessResult
  - FileConfig

#### 8. `utils.py`
- **역할**: 유틸리티 함수
- **주요 기능**:
  - 로그 출력
  - 시간 파싱

### 개선 버전 추가 파일

#### 9. `exceptions.py`
- **역할**: 커스텀 예외 정의
- **주요 내용**:
  - FileNotFoundError
  - DataValidationError
  - 등...

#### 10. `validators.py`
- **역할**: 데이터 검증
- **주요 기능**:
  - 파일 검증
  - DataFrame 검증
  - 출퇴근 데이터 검증

#### 11. `logger.py`
- **역할**: 로깅 시스템
- **주요 기능**:
  - 로그 레벨 관리
  - 색상 표시
  - 로그 이력 저장

---

## 🔍 로그 해석 가이드

### 로그 레벨

#### DEBUG (회색)
```
12:34:56 [DEBUG] 파일 검증 시작: C:\data\attendance.xlsx
```
- **의미**: 디버깅 정보
- **조치**: 필요 없음

#### INFO (검정)
```
12:34:57 [INFO] [2024-12-22] 데이터 로드 완료: 오늘: 45명, 전일: 43명
```
- **의미**: 일반 정보
- **조치**: 필요 없음

#### WARNING (주황)
```
12:34:58 [WARNING] 중복된 이름 발견: 홍길동
```
- **의미**: 경고 (처리는 계속됨)
- **조치**: 확인 필요, 데이터 검토

#### ERROR (빨강)
```
12:34:59 [ERROR] 파일을 찾을 수 없습니다: C:\data\missing.xlsx
```
- **의미**: 에러 발생
- **조치**: 즉시 조치 필요

#### SUCCESS (초록)
```
12:35:00 [SUCCESS] ✓ 모든 작업이 성공적으로 완료되었습니다!
```
- **의미**: 작업 성공
- **조치**: 필요 없음

---

## 📊 데이터 형식 요구사항

### 원시 출퇴근 파일
```
| '근무일자'   | '이름'  | '출근시간'          | '퇴근시간'          |
|-------------|--------|-------------------|-------------------|
| 2024-12-22  | 홍길동  | 2024-12-22 09:00  | 2024-12-22 18:00  |
| 2024-12-22  | 김철수  | 2024-12-22 08:30  | 2024-12-22 17:30  |
```

**주의사항**:
- 컬럼명은 `config.py`에 정의된 것과 정확히 일치해야 함
- 날짜/시간 형식은 Excel에서 인식 가능한 형식이어야 함
- 빈 행은 자동으로 건너뜀

### 근태표 파일 (여주/SMC)
- 마지막 시트가 템플릿으로 사용됨
- 이름, 출근, 퇴근 셀 범위가 `config.py`에 정의되어야 함

---

## ⚙️ 고급 설정

### 1. 날짜 형식 변경
`config.py`에서 수정:
```python
DATE_FORMAT = "%Y-%m-%d"          # 입력 형식
SHEET_NAME_FORMAT = "%y.%m.%d"   # 시트 이름 형식
TIME_FORMAT = "%H:%M"             # 시간 표시 형식
```

### 2. 셀 범위 추가/수정
`config.py`에서 블록 추가:
```python
YEOJU_BLOCKS = [
    ("C9:C11", "D9:D11", "E9:E11"),  # (이름, 출근, 퇴근)
    # 새 블록 추가
    ("C15:C20", "D15:D20", "E15:E20"),
]
```

### 3. 로그 레벨 조정
`logger.py`에서 기본 레벨 변경:
```python
# DEBUG 로그 숨기기
if level >= LogLevel.INFO:
    self.log(message, level)
```

---

## 🎯 베스트 프랙티스

### 1. 파일 백업
작업 전에 항상 원본 파일을 백업하세요:
```bash
# 원본 파일 복사
copy attendance.xlsx attendance_backup.xlsx
```

### 2. 테스트 실행
처음 사용할 때는 테스트 데이터로 먼저 실행하세요.

### 3. 로그 저장
문제 발생 시 로그를 저장하여 분석하세요:
1. 로그 창 전체 선택 (Ctrl+A)
2. 복사 (Ctrl+C)
3. 텍스트 파일로 저장

### 4. 정기 업데이트
Python 패키지를 정기적으로 업데이트하세요:
```bash
pip install --upgrade pandas openpyxl xlrd
```

---

## 📞 지원 및 문의

문제가 발생하면 다음 정보를 제공해주세요:
1. **Python 버전**: `python --version`
2. **패키지 버전**: `pip list | grep -E "pandas|openpyxl|xlrd"`
3. **운영체제**: Windows/macOS/Linux 버전
4. **에러 메시지**: 전체 에러 메시지 및 로그
5. **파일 구조**: 엑셀 파일의 컬럼명 및 구조

---

## 🎉 설치 완료 체크리스트

- [ ] Python 3.8 이상 설치됨
- [ ] pandas, openpyxl, xlrd 패키지 설치됨
- [ ] 모든 .py 파일이 한 폴더에 있음
- [ ] GUI 창이 정상적으로 열림
- [ ] 테스트 데이터로 정상 작동 확인됨
- [ ] 에러 발생 시 로그를 확인할 수 있음

모든 항목을 체크했다면 프로그램 사용 준비가 완료되었습니다! 🚀
