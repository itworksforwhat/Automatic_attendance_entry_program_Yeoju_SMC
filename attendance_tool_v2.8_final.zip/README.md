# 근태 자동 입력 프로그램

출퇴근 원시 데이터를 읽어 여주/SMC 근태표에 자동으로 입력하는 프로그램입니다.

## ✨ 주요 기능

- 📊 **원시 데이터 처리**: Excel 파일에서 출퇴근 데이터 자동 읽기
- 🔄 **주간/야간 근무 판별**: 출근 시간을 기반으로 근무 패턴 자동 인식
- 📝 **근태표 자동 작성**: 여주 및 SMC 근태표에 출퇴근 시간 자동 입력
- 🖥️ **사용자 친화적 GUI**: 간단한 인터페이스로 쉽게 사용
- ✅ **데이터 검증**: 입력 데이터의 유효성 자동 검사
- 📋 **상세한 로그**: 처리 과정을 실시간으로 확인
- 🔧 **.xls 파일 자동 변환**: 구 Excel 형식(.xls)을 자동으로 .xlsx로 변환 ⭐ NEW!

## 🚀 빠른 시작

### 1. 설치

```bash
# 필수 패키지 설치
pip install -r requirements.txt
```

### 2. 실행

```bash
# 프로그램 실행
python main.py
```

### 3. 사용

1. **기준 날짜** 입력 (YYYY-MM-DD 형식, 예: 2024-12-22)
2. **파일 선택**:
   - 출퇴근 원시 파일 (.xls 또는 .xlsx)
   - 여주 근태 파일 (.xlsx)
   - SMC 근태 파일 (.xlsx)
3. **실행** 버튼 클릭
4. 로그 창에서 진행 상황 확인

## 📋 시스템 요구사항

- **Python**: 3.8 이상
- **운영체제**: Windows, macOS, Linux
- **메모리**: 최소 2GB RAM
- **필수 패키지**: pandas, openpyxl, xlrd

## 📂 프로젝트 구조

```
attendance_tool/
│
├── main.py                    # 프로그램 진입점
├── gui.py                     # GUI 인터페이스
├── data_processor.py          # 데이터 처리
├── excel_handler.py           # 엑셀 파일 처리
├── attendance_logic.py        # 출퇴근 로직
├── config.py                  # 설정 파일
├── models.py                  # 데이터 모델
├── utils.py                   # 유틸리티 함수
│
├── exceptions.py              # 커스텀 예외 (개선 버전)
├── validators.py              # 데이터 검증 (개선 버전)
├── logger.py                  # 로깅 시스템 (개선 버전)
├── xls_converter.py           # .xls 변환 도구 (개선 버전) ⭐ NEW
├── batch_convert_xls.py       # .xls 일괄 변환 (유틸리티) ⭐ NEW
│
├── requirements.txt           # 필수 패키지 목록
├── README.md                  # 이 파일
├── INSTALLATION_GUIDE.md      # 상세 설치 가이드
├── IMPROVEMENTS.md            # 개선사항 문서
└── XLS_CONVERSION_GUIDE.md    # .xls 변환 가이드 ⭐ NEW
```

## 🔧 설정

`config.py` 파일에서 다음 항목을 수정할 수 있습니다:

- **컬럼명**: 원시 데이터의 컬럼명 (이름, 근무일자, 출근시간, 퇴근시간)
- **셀 범위**: 근태표의 이름/출근/퇴근 셀 범위
- **날짜 형식**: 날짜 입력 및 표시 형식

## 📊 데이터 형식

### 원시 출퇴근 파일
```
| '근무일자'   | '이름'  | '출근시간'          | '퇴근시간'          |
|-------------|--------|-------------------|-------------------|
| 2024-12-22  | 홍길동  | 2024-12-22 09:00  | 2024-12-22 18:00  |
```

### 근태표 파일
- 마지막 시트가 템플릿으로 사용됨
- 새 시트가 자동으로 생성되어 데이터가 입력됨
- 시트 이름 형식: `YY.MM.DD` (예: 24.12.22)

## ✨ v2.0 개선사항

### 1. .xls 파일 자동 변환 ⭐ NEW!
- 구 Excel 형식(.xls) 자동 감지
- 여러 방법으로 자동 변환 시도 (pywin32, xlrd, pandas)
- 임시 파일 자동 생성 및 삭제
- 변환 실패 시 친절한 안내 메시지

### 2. 예외 처리 강화
- 구체적인 에러 메시지
- 파일/컬럼/날짜 관련 커스텀 예외

### 3. 데이터 검증
- 파일 존재 및 형식 검증
- 필수 컬럼 확인
- 출퇴근 데이터 유효성 검사

### 4. 로깅 시스템
- 로그 레벨 지원 (DEBUG, INFO, WARNING, ERROR, SUCCESS)
- 색상 구분
- 처리 통계 및 품질 보고서

### 5. 사용자 경험
- 단계별 진행 상황 표시
- 데이터 품질 보고서
- 최종 처리 결과 요약

자세한 개선사항은 [IMPROVEMENTS.md](IMPROVEMENTS.md)를 참조하세요.

## 🐛 문제 해결

### 자주 발생하는 문제

#### 1. ModuleNotFoundError
```bash
pip install pandas openpyxl xlrd
```

#### 2. PermissionError (파일 잠금)
- Excel에서 파일을 닫고 다시 시도

#### 3. 컬럼을 찾을 수 없음
- `config.py`의 컬럼명을 실제 데이터와 일치하도록 수정

더 많은 문제 해결 방법은 [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)를 참조하세요.

## 📖 문서

- **[설치 및 실행 가이드](INSTALLATION_GUIDE.md)**: 상세한 설치 및 사용 방법
- **[개선사항 문서](IMPROVEMENTS.md)**: v2.0의 주요 개선사항 및 기술 상세
- **[.xls 변환 가이드](XLS_CONVERSION_GUIDE.md)**: .xls 파일 자동 변환 사용법 ⭐ NEW

## 🎯 로드맵

### 계획된 기능
- [ ] JSON/YAML 기반 설정 파일
- [ ] 진행률 표시 바
- [ ] 로그 파일 자동 저장
- [ ] 명령줄 인터페이스 (CLI 모드)
- [ ] 여러 날짜 일괄 처리
- [ ] 데이터 내보내기 (CSV, JSON)

## 🤝 기여

버그 리포트, 기능 제안, 풀 리퀘스트 환영합니다!

### 개발 환경 설정
```bash
# 가상 환경 생성
python -m venv venv

# 가상 환경 활성화
# Windows: venv\Scripts\activate
# macOS/Linux: source venv/bin/activate

# 개발 패키지 설치
pip install -r requirements.txt
```

## 📝 라이선스

이 프로젝트는 내부 사용을 위한 도구입니다.

## 📞 지원

문제가 발생하면 다음 정보와 함께 문의하세요:
- Python 버전
- 에러 메시지 및 로그
- 파일 구조 (컬럼명)

---

**버전**: 2.0 (개선 버전)  
**최종 업데이트**: 2024년 12월
