# 근태 자동 입력 프로그램 v2.1 업데이트

## 🎉 주요 신기능: .xls 파일 완전 지원!

이제 **구 Excel 형식(.xls) 파일을 자동으로 처리**할 수 있습니다!
더 이상 수동으로 .xlsx로 변환할 필요가 없습니다.

---

## ✨ 새로운 기능

### 1. 🔧 .xls 파일 자동 변환
- .xls 파일 선택 시 자동으로 .xlsx로 변환
- 여러 변환 방법 자동 시도
- 임시 파일 자동 관리

### 2. 📦 새로운 파일들

#### `xls_converter.py`
.xls → .xlsx 자동 변환 모듈
- Windows Excel COM 지원
- xlrd + xlsxwriter 지원
- pandas 변환 지원
- 우선순위에 따라 최적 방법 선택

#### `batch_convert_xls.py`
여러 .xls 파일을 한 번에 변환하는 유틸리티
```bash
python batch_convert_xls.py
```

#### `XLS_CONVERSION_GUIDE.md`
.xls 파일 처리 상세 가이드
- 자동 변환 작동 방식
- 권장 설정
- 문제 해결

---

## 🚀 사용 방법

### 자동 변환 (권장)
1. 프로그램 실행
2. .xls 파일 선택
3. 자동으로 변환되어 처리됨! ✨

### 최적의 성능을 위한 설정

#### Windows 사용자
```bash
pip install pywin32
```

#### 모든 플랫폼
```bash
pip install xlrd==1.2.0 xlsxwriter
```

#### 패키지 없이 사용
- 설치 없이도 작동!
- 변환 실패 시 친절한 안내 메시지

---

## 📊 변환 프로세스

```
사용자가 .xls 파일 선택
         ↓
[1단계] pywin32로 변환 시도
         ↓ (실패 시)
[2단계] xlrd + xlsxwriter로 변환 시도
         ↓ (실패 시)
[3단계] pandas로 변환 시도
         ↓ (모두 실패 시)
수동 변환 안내 메시지 표시
```

---

## 🔄 v2.0 → v2.1 변경사항

### 추가된 파일
- ✅ `xls_converter.py` - .xls 변환 모듈
- ✅ `batch_convert_xls.py` - 일괄 변환 유틸리티
- ✅ `XLS_CONVERSION_GUIDE.md` - .xls 처리 가이드

### 수정된 파일
- 📝 `data_processor_improved.py` - .xls 자동 변환 로직 추가
- 📝 `requirements.txt` - .xls 변환 패키지 정보 추가
- 📝 `README.md` - .xls 지원 정보 추가

### 기존 파일
- ✅ 모든 기존 기능 유지
- ✅ 하위 호환성 보장

---

## 💡 주요 개선사항

### Before (v2.0)
```
[ERROR] xlrd가 설치되지 않음
파일을 .xlsx로 변환해주세요.
```
→ 사용자가 수동으로 변환해야 함

### After (v2.1)
```
[INFO] .xls 파일 감지 - 자동 변환 시도
[SUCCESS] 변환 완료
[INFO] 파일 로딩 완료: 150행
```
→ 자동으로 처리됨! ✨

---

## 📦 설치 및 업데이트

### 신규 설치
```bash
# ZIP 파일 압축 해제
# 필수 패키지 설치
pip install pandas openpyxl

# 선택사항 (.xls 최적화)
pip install pywin32  # Windows
# 또는
pip install xlrd==1.2.0 xlsxwriter  # 모든 플랫폼
```

### 기존 v2.0에서 업데이트
1. 새 파일 3개 추가:
   - `xls_converter.py`
   - `batch_convert_xls.py`
   - `XLS_CONVERSION_GUIDE.md`

2. 기존 파일 교체:
   - `data_processor_improved.py`
   - `requirements.txt`
   - `README.md`

3. 선택사항 - 패키지 설치:
   ```bash
   pip install pywin32  # 권장 (Windows)
   ```

---

## 🎯 사용 시나리오

### 시나리오 1: Windows + pywin32
```
✅ 가장 빠르고 정확한 변환
✅ 모든 서식 보존
✅ 자동 처리
```

### 시나리오 2: xlrd 설치
```
✅ 크로스 플랫폼 지원
✅ 안정적인 변환
✅ 자동 처리
```

### 시나리오 3: 패키지 없음
```
⚠️ 변환 시도 후 실패
📝 친절한 안내 메시지
📋 수동 변환 방법 제공
```

---

## 🐛 알려진 제한사항

### 자동 변환이 안 되는 경우
- 매크로가 포함된 파일
- 암호로 보호된 파일
- 손상된 파일

### 해결 방법
Excel에서 수동으로 변환:
1. 파일 열기
2. "다른 이름으로 저장"
3. 형식: "Excel 통합 문서 (*.xlsx)"
4. 저장

---

## 📈 성능 비교

| 변환 방법 | 속도 | 정확도 | 설치 필요 |
|----------|------|--------|----------|
| pywin32 | ⭐⭐⭐ | ⭐⭐⭐ | Windows만 |
| xlrd | ⭐⭐ | ⭐⭐ | 모든 OS |
| pandas | ⭐ | ⭐⭐ | 모든 OS |
| 수동 | ⭐⭐⭐ | ⭐⭐⭐ | Excel 필요 |

---

## 🎉 요약

### v2.1의 핵심
**"xlrd 오류? 이제 걱정 없습니다!"**

- ✅ .xls 파일 완전 지원
- ✅ 자동 변환 (3가지 방법)
- ✅ 사용자 친화적
- ✅ 하위 호환성 유지

---

## 📞 지원

### .xls 변환 관련 문의
`XLS_CONVERSION_GUIDE.md` 참조

### 일반 문의
`INSTALLATION_GUIDE.md` 참조

---

**버전**: 2.1 (XLS Support)  
**릴리스 날짜**: 2024년 12월  
**호환성**: v2.0의 모든 기능 포함
