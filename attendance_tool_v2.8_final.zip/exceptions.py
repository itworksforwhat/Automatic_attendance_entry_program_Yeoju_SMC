"""
attendance_tool/exceptions.py
커스텀 예외 클래스 정의
"""


class AttendanceToolError(Exception):
    """근태 도구 기본 예외 클래스"""
    pass


class FileNotFoundError(AttendanceToolError):
    """파일을 찾을 수 없을 때 발생하는 예외"""
    def __init__(self, file_path: str):
        self.file_path = file_path
        super().__init__(f"파일을 찾을 수 없습니다: {file_path}")


class InvalidFileFormatError(AttendanceToolError):
    """파일 형식이 올바르지 않을 때 발생하는 예외"""
    def __init__(self, file_path: str, expected_format: str, detail: str = ""):
        self.file_path = file_path
        self.expected_format = expected_format
        message = f"파일 형식이 올바르지 않습니다: {file_path}\n예상 형식: {expected_format}"
        if detail:
            message += f"\n상세: {detail}"
        super().__init__(message)


class DataValidationError(AttendanceToolError):
    """데이터 검증 실패 시 발생하는 예외"""
    def __init__(self, message: str, details: dict = None):
        self.details = details or {}
        super().__init__(message)


class SheetNotFoundError(AttendanceToolError):
    """시트를 찾을 수 없을 때 발생하는 예외"""
    def __init__(self, sheet_name: str, file_path: str):
        self.sheet_name = sheet_name
        self.file_path = file_path
        super().__init__(f"시트를 찾을 수 없습니다: '{sheet_name}' in {file_path}")


class ColumnNotFoundError(AttendanceToolError):
    """필수 컬럼을 찾을 수 없을 때 발생하는 예외"""
    def __init__(self, column_name: str, available_columns: list):
        self.column_name = column_name
        self.available_columns = available_columns
        message = f"필수 컬럼을 찾을 수 없습니다: {column_name}\n"
        message += f"사용 가능한 컬럼: {', '.join(map(str, available_columns))}"
        super().__init__(message)


class DateParsingError(AttendanceToolError):
    """날짜 파싱 실패 시 발생하는 예외"""
    def __init__(self, date_str: str, expected_format: str):
        self.date_str = date_str
        self.expected_format = expected_format
        super().__init__(
            f"날짜 형식이 올바르지 않습니다: '{date_str}'\n"
            f"예상 형식: {expected_format}"
        )
