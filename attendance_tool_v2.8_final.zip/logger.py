"""
attendance_tool/logger.py
개선된 로깅 시스템
"""

import tkinter as tk
from datetime import datetime
from enum import Enum
from typing import Optional


class LogLevel(Enum):
    """로그 레벨"""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    SUCCESS = "SUCCESS"


class Logger:
    """개선된 로거 클래스"""

    # 로그 레벨별 색상 태그 (Tkinter Text 위젯용)
    COLOR_MAP = {
        LogLevel.DEBUG: "gray",
        LogLevel.INFO: "black",
        LogLevel.WARNING: "orange",
        LogLevel.ERROR: "red",
        LogLevel.SUCCESS: "green",
    }

    def __init__(self, text_widget: Optional[tk.Text] = None):
        """
        초기화

        Args:
            text_widget: Tkinter Text 위젯 (GUI 모드)
        """
        self.text_widget = text_widget
        self.log_history = []  # 로그 이력 저장
        
        # 색상 태그 설정
        if self.text_widget:
            self._setup_color_tags()

    def _setup_color_tags(self):
        """Text 위젯에 색상 태그 설정"""
        if not self.text_widget:
            return

        self.text_widget.tag_config("gray", foreground="#666666")
        self.text_widget.tag_config("black", foreground="#000000")
        self.text_widget.tag_config("orange", foreground="#FF8C00")
        self.text_widget.tag_config("red", foreground="#DC143C")
        self.text_widget.tag_config("green", foreground="#228B22")

    def log(
            self,
            message: str,
            level: LogLevel = LogLevel.INFO,
            base_date: Optional[datetime.date] = None,
            prefix: str = ""
    ):
        """
        로그 메시지 출력

        Args:
            message: 로그 메시지
            level: 로그 레벨
            base_date: 기준 날짜 (있으면 메시지 앞에 표시)
            prefix: 추가 접두사
        """
        # 타임스탬프 생성
        timestamp = datetime.now().strftime("%H:%M:%S")

        # 날짜 정보 추가 (NaT 안전 체크)
        date_str = ""
        if base_date is not None:
            try:
                # pandas NaT 체크
                import pandas as pd
                if not pd.isna(base_date) and hasattr(base_date, "strftime"):
                    date_str = f"[{base_date.strftime('%Y-%m-%d')}] "
            except (ImportError, AttributeError):
                # pandas가 없거나 일반 date 객체인 경우
                if hasattr(base_date, "strftime"):
                    try:
                        date_str = f"[{base_date.strftime('%Y-%m-%d')}] "
                    except:
                        pass  # strftime 실패 시 무시

        # 레벨 표시
        level_str = f"[{level.value}] "

        # 최종 메시지 조합
        full_message = f"{timestamp} {level_str}{date_str}{prefix}{message}"

        # 로그 이력에 저장
        self.log_history.append({
            "timestamp": timestamp,
            "level": level,
            "date": base_date,
            "message": message,
            "full_message": full_message
        })

        # GUI 출력
        if self.text_widget:
            color_tag = self.COLOR_MAP.get(level, "black")
            self.text_widget.insert(tk.END, full_message + "\n", color_tag)
            self.text_widget.see(tk.END)
            self.text_widget.update()
        else:
            # 콘솔 출력
            print(full_message)

    def debug(self, message: str, **kwargs):
        """디버그 로그"""
        self.log(message, LogLevel.DEBUG, **kwargs)

    def info(self, message: str, **kwargs):
        """정보 로그"""
        self.log(message, LogLevel.INFO, **kwargs)

    def warning(self, message: str, **kwargs):
        """경고 로그"""
        self.log(message, LogLevel.WARNING, **kwargs)

    def error(self, message: str, **kwargs):
        """에러 로그"""
        self.log(message, LogLevel.ERROR, **kwargs)

    def success(self, message: str, **kwargs):
        """성공 로그"""
        self.log(message, LogLevel.SUCCESS, **kwargs)

    def separator(self, char: str = "=", length: int = 60):
        """구분선 출력"""
        self.log(char * length, LogLevel.INFO)

    def section(self, title: str, char: str = "=", length: int = 60):
        """섹션 헤더 출력"""
        self.separator(char, length)
        self.log(title, LogLevel.INFO)
        self.separator(char, length)

    def clear(self):
        """로그 화면 지우기"""
        if self.text_widget:
            self.text_widget.delete(1.0, tk.END)
        self.log_history.clear()

    def get_history(self, level: Optional[LogLevel] = None):
        """
        로그 이력 조회

        Args:
            level: 특정 레벨만 조회 (None이면 전체)

        Returns:
            list: 로그 이력
        """
        if level:
            return [log for log in self.log_history if log["level"] == level]
        return self.log_history

    def has_errors(self) -> bool:
        """에러 로그가 있는지 확인"""
        return any(log["level"] == LogLevel.ERROR for log in self.log_history)

    def has_warnings(self) -> bool:
        """경고 로그가 있는지 확인"""
        return any(log["level"] == LogLevel.WARNING for log in self.log_history)

    def get_error_count(self) -> int:
        """에러 개수 반환"""
        return len(self.get_history(LogLevel.ERROR))

    def get_warning_count(self) -> int:
        """경고 개수 반환"""
        return len(self.get_history(LogLevel.WARNING))

    def print_summary(self):
        """로그 요약 정보 출력"""
        error_count = self.get_error_count()
        warning_count = self.get_warning_count()

        self.separator("-")
        self.info(f"로그 요약: 총 {len(self.log_history)}개")
        
        if error_count > 0:
            self.error(f"에러: {error_count}개")
        
        if warning_count > 0:
            self.warning(f"경고: {warning_count}개")
        
        self.separator("-")


# 전역 로거 인스턴스 (하위 호환성을 위해 유지)
_global_logger: Optional[Logger] = None


def initialize_logger(text_widget: Optional[tk.Text] = None) -> Logger:
    """
    전역 로거 초기화

    Args:
        text_widget: Tkinter Text 위젯

    Returns:
        Logger: 로거 인스턴스
    """
    global _global_logger
    _global_logger = Logger(text_widget)
    return _global_logger


def get_logger() -> Logger:
    """전역 로거 인스턴스 반환"""
    global _global_logger
    if _global_logger is None:
        _global_logger = Logger()
    return _global_logger


# 하위 호환성을 위한 함수 (기존 utils.log 대체)
def log(text_widget: tk.Text, msg: str, base_date=None):
    """
    기존 log 함수와 호환되는 래퍼 함수

    Args:
        text_widget: Tkinter Text 위젯
        msg: 로그 메시지
        base_date: 기준 날짜
    """
    logger = Logger(text_widget)
    logger.info(msg, base_date=base_date)
