"""
attendance_tool/data_processor.py (개선 버전)
원시 출퇴근 데이터 처리: 파일 읽기, 날짜별 분리, 맵 생성
"""

import pandas as pd
from datetime import datetime, timedelta
from typing import Tuple, Dict, Optional
from config import COL_DATE, COL_NAME, COL_IN_RAW, COL_OUT_RAW, ALL_HOLIDAYS
from utils import extract_time_str
from validators import (
    FileValidator,
    DataFrameValidator,
    AttendanceDataValidator
)
from exceptions import DataValidationError, InvalidFileFormatError
from logger import Logger
from xls_converter import convert_xls_to_xlsx


class DataProcessor:
    """원시 출퇴근 데이터를 처리하는 클래스 (개선 버전)"""

    def __init__(
            self,
            file_path: str,
            base_date: datetime.date,
            logger: Optional[Logger] = None
    ):
        """
        초기화

        Args:
            file_path: 원시 출퇴근 파일 경로
            base_date: 기준 날짜
            logger: 로거 인스턴스
        """
        self.file_path = file_path
        self.base_date = base_date
        self.yesterday = base_date - timedelta(days=1)
        self.df_today = None
        self.df_yesterday = None
        self.logger = logger or Logger()

        # 필수 컬럼 정의
        self.required_columns = [COL_DATE, COL_NAME, COL_IN_RAW, COL_OUT_RAW]
        
        # 공휴일 목록 (config에서 가져오기)
        self.holidays = set()
        for holiday_str in ALL_HOLIDAYS:
            try:
                holiday_date = datetime.strptime(holiday_str, "%Y-%m-%d").date()
                self.holidays.add(holiday_date)
            except:
                pass  # 잘못된 형식은 무시
    
    def is_workday(self, check_date: datetime.date) -> bool:
        """
        근무일 여부 확인 (월~금, 공휴일 제외)
        
        Args:
            check_date: 확인할 날짜
            
        Returns:
            bool: 근무일이면 True
        """
        # 토요일(5) 또는 일요일(6)
        if check_date.weekday() >= 5:
            return False
        
        # 공휴일
        if check_date in self.holidays:
            return False
            
        return True
    
    def find_previous_workday(self, from_date: datetime.date, max_days: int = 7) -> Optional[datetime.date]:
        """
        이전 근무일 찾기
        
        Args:
            from_date: 시작 날짜
            max_days: 최대 검색 일수
            
        Returns:
            Optional[date]: 이전 근무일, 없으면 None
        """
        current = from_date - timedelta(days=1)
        
        for _ in range(max_days):
            if self.is_workday(current):
                return current
            current -= timedelta(days=1)
        
        return None

    def validate_file(self) -> bool:
        """
        파일 검증

        Returns:
            bool: 검증 통과 시 True

        Raises:
            FileNotFoundError, InvalidFileFormatError
        """
        self.logger.debug(f"파일 검증 시작: {self.file_path}")
        FileValidator.validate_all(self.file_path)
        self.logger.debug("파일 검증 완료")
        return True

    def load_file(self) -> pd.DataFrame:
        """
        엑셀 파일을 읽어 DataFrame으로 반환 (개선된 에러 처리)
        .xls 파일은 자동으로 .xlsx로 변환하여 처리

        Returns:
            pd.DataFrame: 원시 데이터

        Raises:
            InvalidFileFormatError: 파일 읽기 실패 시
        """
        self.logger.info(f"파일 로딩 중: {self.file_path}")

        try:
            # 파일 검증
            self.validate_file()

            # .xls 파일 처리 - 자동 변환
            if self.file_path.lower().endswith(".xls"):
                self.logger.info(".xls 파일 감지 - 자동 변환 시도")
                
                # 임시 .xlsx 파일 경로 생성
                temp_xlsx_path = self.file_path.replace(".xls", "_temp.xlsx")
                
                # 자동 변환 시도
                converted_path = convert_xls_to_xlsx(
                    self.file_path,
                    temp_xlsx_path,
                    self.logger
                )
                
                if converted_path:
                    # 변환 성공 - xlsx 파일 읽기
                    self.logger.info(f"변환된 파일 사용: {converted_path}")
                    df = pd.read_excel(converted_path, engine="openpyxl")
                    
                    # 임시 파일 삭제 (원본 유지)
                    import os
                    if os.path.exists(temp_xlsx_path):
                        try:
                            os.remove(temp_xlsx_path)
                            self.logger.debug(f"임시 파일 삭제: {temp_xlsx_path}")
                        except:
                            pass  # 삭제 실패해도 무시
                else:
                    # 변환 실패 - 수동 변환 안내
                    raise InvalidFileFormatError(
                        self.file_path,
                        "Excel 파일 (.xlsx)",
                        ".xls 파일 자동 변환에 실패했습니다.\n\n"
                        "다음 방법 중 하나를 시도해주세요:\n\n"
                        "방법 1 (권장): Excel에서 수동 변환\n"
                        "  1. Excel로 파일 열기\n"
                        "  2. '다른 이름으로 저장' 클릭\n"
                        "  3. 파일 형식을 'Excel 통합 문서 (*.xlsx)'로 선택\n"
                        "  4. 저장 후 프로그램에서 .xlsx 파일 선택\n\n"
                        "방법 2: 필요한 패키지 설치\n"
                        "  Windows: pip install pywin32\n"
                        "  또는: pip install xlrd==1.2.0 xlsxwriter"
                    )
            else:
                # .xlsx, .xlsm 파일은 직접 읽기
                df = pd.read_excel(self.file_path, engine="openpyxl")

            self.logger.info(f"파일 로딩 완료: {len(df)}행")
            return df

        except InvalidFileFormatError:
            # 이미 포맷된 에러는 그대로 전달
            raise
        except Exception as e:
            self.logger.error(f"파일 로딩 실패: {str(e)}")
            raise InvalidFileFormatError(
                self.file_path,
                "Excel 파일",
                str(e)
            )

    def validate_dataframe(self, df: pd.DataFrame) -> bool:
        """
        DataFrame 검증

        Args:
            df: 검증할 DataFrame

        Returns:
            bool: 검증 통과 시 True

        Raises:
            ColumnNotFoundError, DataValidationError
        """
        self.logger.debug("DataFrame 검증 시작")

        # 필수 컬럼 확인
        DataFrameValidator.validate_required_columns(df, self.required_columns)

        # 데이터 비어있는지 확인
        DataFrameValidator.validate_not_empty(df, "원시 출퇴근 데이터")

        # 날짜 범위 검증
        is_valid, stats = DataFrameValidator.validate_date_range(
            df, COL_DATE,
            start_date=self.yesterday - timedelta(days=7),
            end_date=self.base_date + timedelta(days=1)
        )

        # 날짜 통계 로깅
        self.logger.info(f"날짜 범위: {stats.get('min_date')} ~ {stats.get('max_date')}")
        
        if stats.get('invalid_dates', 0) > 0:
            self.logger.warning(
                f"유효하지 않은 날짜: {stats['invalid_dates']}개"
            )

        self.logger.debug("DataFrame 검증 완료")
        return True

    def parse_datetime_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        날짜/시간 컬럼을 datetime 형식으로 변환 (개선된 에러 처리)

        Args:
            df: 원본 DataFrame

        Returns:
            pd.DataFrame: 변환된 DataFrame
        """
        self.logger.debug("날짜/시간 컬럼 파싱 중")

        try:
            df[COL_DATE] = pd.to_datetime(df[COL_DATE], errors='coerce')
            df[COL_IN_RAW] = pd.to_datetime(df[COL_IN_RAW], errors='coerce')
            df[COL_OUT_RAW] = pd.to_datetime(df[COL_OUT_RAW], errors='coerce')

            # NaT(Not a Time) 개수 확인
            nat_counts = {
                COL_DATE: df[COL_DATE].isna().sum(),
                COL_IN_RAW: df[COL_IN_RAW].isna().sum(),
                COL_OUT_RAW: df[COL_OUT_RAW].isna().sum(),
            }

            # 경고 로그
            for col, count in nat_counts.items():
                if count > 0:
                    self.logger.warning(
                        f"{col} 컬럼에 파싱 실패한 값: {count}개"
                    )

            self.logger.debug("날짜/시간 컬럼 파싱 완료")
            return df

        except Exception as e:
            self.logger.error(f"날짜/시간 파싱 중 오류: {str(e)}")
            raise DataValidationError(f"날짜/시간 파싱 실패: {str(e)}")

    def split_by_date(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        DataFrame을 오늘 데이터와 전일 데이터로 분리
        월요일이나 공휴일 다음 날인 경우 이전 근무일 자동 검색

        Args:
            df: 전체 DataFrame

        Returns:
            (오늘 데이터, 전일 데이터)
        """
        self.logger.debug(f"데이터 분리 중 (기준일: {self.base_date})")

        # 기준 날짜에 해당하는 행 필터링
        df_today = df[df[COL_DATE].dt.date == self.base_date].copy()

        # 전일 날짜에 해당하는 행 필터링
        df_yesterday = df[df[COL_DATE].dt.date == self.yesterday].copy()

        self.logger.info(
            f"데이터 분리 완료 - 오늘: {len(df_today)}행, 전일: {len(df_yesterday)}행"
        )

        # 월요일인지 확인
        is_monday = self.base_date.weekday() == 0
        # 공휴일 다음 날인지 확인 (전일이 공휴일)
        is_after_holiday = self.yesterday in self.holidays
        
        # 월요일이거나 공휴일 다음 날이면 이전 근무일 검색 ⭐ 수정
        if is_monday or is_after_holiday:
            reason = "월요일" if is_monday else "공휴일 다음 날"
            self.logger.info(f"{reason}이므로 이전 근무일 검색 중...")
            
            # 이전 근무일 찾기
            prev_workday = self.find_previous_workday(self.base_date)
            
            if prev_workday:
                self.logger.info(f"이전 근무일 발견: {prev_workday}")
                df_yesterday = df[df[COL_DATE].dt.date == prev_workday].copy()
                
                if not df_yesterday.empty:
                    self.logger.success(
                        f"이전 근무일({prev_workday}) 데이터 로드 완료: {len(df_yesterday)}행"
                    )
                    # yesterday 값 업데이트
                    self.yesterday = prev_workday
                else:
                    self.logger.warning(f"이전 근무일({prev_workday}) 데이터도 없습니다.")
            else:
                self.logger.warning("이전 근무일을 찾을 수 없습니다 (최근 7일 내)")
        
        # 전일 데이터가 없는 경우 (월요일/공휴일 아닌데도 데이터 없음)
        elif df_yesterday.empty:
            self.logger.warning(f"전일({self.yesterday}) 데이터가 없습니다.")

        return df_today, df_yesterday

    def add_time_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        시간 정보를 추출하여 새로운 컬럼 추가

        Args:
            df: DataFrame

        Returns:
            pd.DataFrame: 컬럼이 추가된 DataFrame
        """
        self.logger.debug("시간 정보 컬럼 추가 중")

        # 출근/퇴근 시각을 'HH:MM' 문자열로 변환
        df["출근시각"] = df[COL_IN_RAW].apply(extract_time_str)
        df["퇴근시각"] = df[COL_OUT_RAW].apply(extract_time_str)

        # 출근/퇴근 날짜 (date만 추출)
        df["출근일자"] = df[COL_IN_RAW].dt.date
        df["퇴근일자"] = df[COL_OUT_RAW].dt.date

        self.logger.debug("시간 정보 컬럼 추가 완료")
        return df

    def process(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        전체 처리 프로세스 실행 (개선된 에러 처리 및 로깅)

        Returns:
            (오늘 데이터, 전일 데이터)
        """
        self.logger.info("=" * 60)
        self.logger.info("데이터 처리 시작")
        self.logger.info("=" * 60)

        try:
            # 1. 파일 읽기
            df = self.load_file()

            # 2. DataFrame 검증
            self.validate_dataframe(df)

            # 3. 날짜/시간 컬럼 파싱
            df = self.parse_datetime_columns(df)

            # 4. 오늘/전일 데이터 분리
            df_today, df_yesterday = self.split_by_date(df)

            # 5. 시간 정보 추가
            df_today = self.add_time_columns(df_today)
            df_yesterday = self.add_time_columns(df_yesterday)

            # 인스턴스 변수에 저장
            self.df_today = df_today
            self.df_yesterday = df_yesterday

            self.logger.success("데이터 처리 완료")
            return df_today, df_yesterday

        except Exception as e:
            self.logger.error(f"데이터 처리 중 오류 발생: {str(e)}")
            raise

    @staticmethod
    def build_attendance_map(df: pd.DataFrame, logger: Optional[Logger] = None) -> Dict[str, dict]:
        """
        DataFrame을 이름 기준 딕셔너리로 변환

        Args:
            df: 출퇴근 데이터 DataFrame
            logger: 로거 인스턴스

        Returns:
            dict: {이름: {출근시각, 퇴근시각, 출근일자, 퇴근일자}}
        """
        if logger is None:
            logger = Logger()

        logger.debug("출퇴근 맵 생성 중")

        attendance_map = {}
        duplicate_names = []

        for _, row in df.iterrows():
            # 이름을 키로 사용 (공백 제거)
            name = str(row[COL_NAME]).strip()

            # 중복 이름 체크
            if name in attendance_map:
                duplicate_names.append(name)
                logger.warning(f"중복된 이름 발견: {name}")

            # 출퇴근 정보를 딕셔너리로 저장
            attendance_map[name] = {
                "출근시각": row["출근시각"],
                "퇴근시각": row["퇴근시각"],
                "출근일자": row["출근일자"],
                "퇴근일자": row["퇴근일자"],
            }

        logger.info(f"출퇴근 맵 생성 완료: {len(attendance_map)}명")

        if duplicate_names:
            # set을 list로 변환 후 슬라이싱
            unique_duplicates = list(set(duplicate_names))
            logger.warning(
                f"중복 이름 {len(unique_duplicates)}개: "
                f"{', '.join(unique_duplicates[:5])}..."
            )

        return attendance_map


def load_and_process_data(
        file_path: str,
        base_date: datetime.date,
        logger: Optional[Logger] = None
) -> Tuple[Dict, Dict]:
    """
    편의 함수: 파일 읽기부터 맵 생성까지 한 번에 처리 (개선 버전)

    Args:
        file_path: 원시 출퇴근 파일 경로
        base_date: 기준 날짜
        logger: 로거 인스턴스

    Returns:
        (오늘 맵, 전일 맵)
    """
    if logger is None:
        logger = Logger()

    # 데이터 처리
    processor = DataProcessor(file_path, base_date, logger)
    df_today, df_yesterday = processor.process()

    # 이름 기준 맵 생성
    today_map = processor.build_attendance_map(df_today, logger)
    yesterday_map = processor.build_attendance_map(df_yesterday, logger)

    # 데이터 품질 보고서 생성
    report = AttendanceDataValidator.generate_data_quality_report(
        today_map, yesterday_map
    )

    # 품질 보고서 로깅
    logger.info("-" * 60)
    logger.info("데이터 품질 보고서")
    logger.info("-" * 60)
    logger.info(
        f"오늘: 전체 {report['today']['total']}명 "
        f"(완료 {report['today']['complete']}, "
        f"미완료 {report['today']['incomplete']})"
    )
    logger.info(
        f"전일: 전체 {report['yesterday']['total']}명 "
        f"(완료 {report['yesterday']['complete']}, "
        f"미완료 {report['yesterday']['incomplete']})"
    )

    # 경고 메시지 출력
    if report['today']['warnings']:
        logger.warning(f"오늘 데이터 경고: {len(report['today']['warnings'])}건")
        for item in report['today']['warnings'][:3]:  # 최대 3개만 표시
            logger.warning(f"  - {item['name']}: {', '.join(item['warnings'])}")

    if report['yesterday']['warnings']:
        logger.warning(f"전일 데이터 경고: {len(report['yesterday']['warnings'])}건")
        for item in report['yesterday']['warnings'][:3]:
            logger.warning(f"  - {item['name']}: {', '.join(item['warnings'])}")

    logger.info("-" * 60)

    return today_map, yesterday_map
