"""
attendance_tool/main.py (개선 버전)
프로그램 진입점: 모든 모듈을 연결하여 근태 자동 입력 실행
"""

import traceback
import tkinter as tk
from tkinter import messagebox
from datetime import datetime, timedelta
from typing import Optional

from config import (
    YEOJU_BLOCKS, SMC_BLOCKS,
    CLEAR_RANGES_YEOJU, CLEAR_RANGES_SMC
)
from models import FileConfig
from data_processor_improved import load_and_process_data
from excel_handler_improved import prepare_attendance_sheet, fill_attendance_file
from utils import today_sheet_name
from gui import create_gui
from logger import Logger, LogLevel, initialize_logger
from exceptions import AttendanceToolError


class AttendanceProcessor:
    """근태 처리 메인 클래스 (개선 버전)"""

    def __init__(self):
        """초기화"""
        self.logger: Optional[Logger] = None

    def process(self, file_config: FileConfig, logbox: tk.Text):
        """
        전체 근태 처리 프로세스 실행 (개선된 에러 처리 및 로깅)

        Args:
            file_config: 파일 설정 정보
            logbox: 로그 출력용 Text 위젯
        """
        # 로거 초기화
        self.logger = initialize_logger(logbox)
        
        try:
            # === 시작 메시지 ===
            self.logger.section("근태 자동 입력 시작")

            # === 1단계: 기준 날짜 파싱 ===
            base_date = self._parse_base_date(file_config.base_date_str)
            yesterday = base_date - timedelta(days=1)

            self.logger.info(f"기준 날짜: {base_date} (전일: {yesterday})")
            self.logger.separator("-")

            # === 2단계: 원시 데이터 로드 ===
            self.logger.info("[1단계] 원시 파일 읽기", base_date=base_date)
            self.logger.info(f"  파일: {file_config.raw_file}")

            today_map, yesterday_map = load_and_process_data(
                file_config.raw_file, base_date, self.logger
            )

            self.logger.success(
                f"데이터 로드 완료 - 오늘: {len(today_map)}명, 전일: {len(yesterday_map)}명",
                base_date=base_date
            )

            # === 3단계: 여주 근태표 처리 ===
            self._process_attendance_file(
                file_name="여주",
                file_path=file_config.yeoju_file,
                clear_ranges=CLEAR_RANGES_YEOJU,
                blocks=YEOJU_BLOCKS,
                today_map=today_map,
                yesterday_map=yesterday_map,
                base_date=base_date,
                logbox=logbox
            )

            # === 4단계: SMC 근태표 처리 ===
            self._process_attendance_file(
                file_name="SMC",
                file_path=file_config.smc_file,
                clear_ranges=CLEAR_RANGES_SMC,
                blocks=SMC_BLOCKS,
                today_map=today_map,
                yesterday_map=yesterday_map,
                base_date=base_date,
                logbox=logbox
            )

            # === 완료 ===
            self.logger.separator("=")
            
            # 최종 요약
            if self.logger.has_errors():
                self.logger.error(
                    f"⚠ 작업 완료 (오류 {self.logger.get_error_count()}건)",
                    base_date=base_date
                )
                messagebox.showwarning(
                    "완료 (경고)",
                    f"근태 업데이트가 완료되었으나 {self.logger.get_error_count()}개의 오류가 발생했습니다.\n"
                    "로그를 확인해주세요."
                )
            elif self.logger.has_warnings():
                self.logger.success(
                    f"✓ 작업 완료 (경고 {self.logger.get_warning_count()}건)",
                    base_date=base_date
                )
                messagebox.showinfo(
                    "완료",
                    f"근태 업데이트가 완료되었습니다.\n"
                    f"({self.logger.get_warning_count()}개의 경고가 있습니다)"
                )
            else:
                self.logger.success("✓ 모든 작업이 성공적으로 완료되었습니다!", base_date=base_date)
                messagebox.showinfo("완료", "근태 업데이트가 완료되었습니다.")
            
            self.logger.separator("=")

        except AttendanceToolError as e:
            # 커스텀 예외 처리
            self.logger.separator("=")
            self.logger.error("❌ 처리 중 오류 발생")
            self.logger.separator("=")
            self.logger.error(str(e))

            messagebox.showerror("오류", str(e))

        except Exception as e:
            # 일반 예외 처리
            self.logger.separator("=")
            self.logger.error("❌ 예기치 않은 오류 발생")
            self.logger.separator("=")
            self.logger.error(str(e))
            self.logger.error("\n상세 오류 정보:")
            
            # 트레이스백 출력
            for line in traceback.format_exc().split('\n'):
                if line.strip():
                    self.logger.error(line)

            messagebox.showerror(
                "오류",
                f"처리 중 예기치 않은 오류가 발생했습니다:\n\n{str(e)}\n\n"
                f"자세한 내용은 로그를 확인해주세요."
            )

    def _parse_base_date(self, date_str: str) -> datetime.date:
        """
        기준 날짜 문자열 파싱

        Args:
            date_str: 날짜 문자열 (YYYY-MM-DD)

        Returns:
            datetime.date: 파싱된 날짜
        """
        try:
            if date_str:
                return datetime.strptime(date_str, "%Y-%m-%d").date()
            else:
                return datetime.today().date()

        except ValueError as e:
            from exceptions import DateParsingError
            raise DateParsingError(date_str, "YYYY-MM-DD")

    def _process_attendance_file(
            self,
            file_name: str,
            file_path: str,
            clear_ranges: list,
            blocks: list,
            today_map: dict,
            yesterday_map: dict,
            base_date: datetime.date,
            logbox: tk.Text
    ):
        """
        근태 파일 처리 (공통 로직)

        Args:
            file_name: 파일 이름 (로그용)
            file_path: 파일 경로
            clear_ranges: 지울 범위 리스트
            blocks: 블록 리스트
            today_map: 오늘 데이터 맵
            yesterday_map: 전일 데이터 맵
            base_date: 기준 날짜
            logbox: 로그 출력용 Text 위젯
        """
        self.logger.info(f"\n[{file_name} 근태표 처리]", base_date=base_date)
        self.logger.info(f"  파일: {file_path}")

        # 시트 이름 생성
        sheet_name = today_sheet_name()

        # 시트 준비 (복사 + 기존 데이터 지우기)
        self.logger.info(f"  시트 준비 중: '{sheet_name}'", base_date=base_date)
        
        try:
            prepare_attendance_sheet(
                file_path,
                sheet_name,
                clear_ranges,
                self.logger
            )
        except Exception as e:
            self.logger.error(f"{file_name} 시트 준비 실패: {str(e)}")
            raise

        # 출퇴근 데이터 채우기
        self.logger.info(f"  출퇴근 데이터 입력 중...", base_date=base_date)
        
        try:
            fill_attendance_file(
                file_path,
                sheet_name,
                blocks,
                today_map,
                yesterday_map,
                logbox,
                self.logger
            )
            self.logger.success(f"{file_name} 근태표 업데이트 완료", base_date=base_date)
            
        except Exception as e:
            self.logger.error(f"{file_name} 데이터 입력 실패: {str(e)}")
            raise


def main():
    """프로그램 메인 함수"""
    try:
        # 근태 처리기 생성
        processor = AttendanceProcessor()

        # GUI 생성 (실행 버튼 클릭 시 processor.process 호출)
        gui = create_gui(on_run_callback=processor.process)

        # GUI 실행
        gui.run()

    except Exception as e:
        # GUI 생성 실패 시 에러 메시지 박스 표시
        messagebox.showerror(
            "초기화 오류",
            f"프로그램 초기화 중 오류가 발생했습니다:\n{str(e)}"
        )
        raise


if __name__ == "__main__":
    main()
