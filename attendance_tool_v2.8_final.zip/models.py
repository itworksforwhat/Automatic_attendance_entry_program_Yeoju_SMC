"""
attendance_tool/models.py
데이터 모델: 출퇴근 정보를 담는 클래스 정의
"""

from dataclasses import dataclass
from datetime import date
from typing import Optional


@dataclass
class AttendanceRecord:
    """
    직원 1명의 출퇴근 기록을 담는 데이터 클래스

    Attributes:
        name: 직원 이름
        check_in_time: 출근 시각 (HH:MM 형식)
        check_out_time: 퇴근 시각 (HH:MM 형식)
        check_in_date: 출근 날짜
        check_out_date: 퇴근 날짜
    """
    name: str
    check_in_time: str = ""
    check_out_time: str = ""
    check_in_date: Optional[date] = None
    check_out_date: Optional[date] = None

    def __post_init__(self):
        """초기화 후 이름에서 공백 제거"""
        if self.name:
            self.name = self.name.strip()

    def to_dict(self) -> dict:
        """딕셔너리로 변환"""
        return {
            "출근시각": self.check_in_time,
            "퇴근시각": self.check_out_time,
            "출근일자": self.check_in_date,
            "퇴근일자": self.check_out_date,
        }


@dataclass
class ProcessResult:
    """
    출퇴근 처리 결과를 담는 데이터 클래스

    Attributes:
        check_in: 최종 출근 시각
        check_out: 최종 퇴근 시각
        base_date: 이 기록이 속하는 기준 날짜
        pattern: 근무 패턴 ('day', 'night', 'other', 'absent')
    """
    check_in: str = ""
    check_out: str = ""
    base_date: Optional[date] = None
    pattern: str = "other"  # 'day', 'night', 'other', 'absent'

    def is_absent(self) -> bool:
        """결근 여부 확인"""
        return not self.check_in and not self.check_out

    def is_complete(self) -> bool:
        """출근과 퇴근이 모두 있는지 확인"""
        return bool(self.check_in and self.check_out)


@dataclass
class AttendanceBlock:
    """
    엑셀 근태표의 한 블록 정보

    Attributes:
        name_range: 이름이 있는 셀 범위 (예: "C9:C11")
        check_in_range: 출근 시각을 입력할 셀 범위
        check_out_range: 퇴근 시각을 입력할 셀 범위
        description: 블록 설명 (예: "생산기술/생산관리")
    """
    name_range: str
    check_in_range: str
    check_out_range: str
    description: str = ""

    def __post_init__(self):
        """초기화 후 범위 문자열에서 공백 제거"""
        self.name_range = self.name_range.strip()
        self.check_in_range = self.check_in_range.strip()
        self.check_out_range = self.check_out_range.strip()


@dataclass
class FileConfig:
    """
    파일 경로 설정

    Attributes:
        raw_file: 원시 출퇴근 파일 경로
        yeoju_file: 여주 근태 파일 경로
        smc_file: SMC 근태 파일 경로
        base_date_str: 기준 날짜 문자열 (YYYY-MM-DD)
    """
    raw_file: str
    yeoju_file: str
    smc_file: str
    base_date_str: str

    def validate(self) -> tuple[bool, str]:
        """
        파일 경로가 모두 입력되었는지 검증

        Returns:
            (성공 여부, 에러 메시지)
        """
        if not self.raw_file:
            return False, "출퇴근 원시 파일을 선택해주세요."
        if not self.yeoju_file:
            return False, "여주 근태 파일을 선택해주세요."
        if not self.smc_file:
            return False, "SMC 근태 파일을 선택해주세요."
        if not self.base_date_str:
            return False, "기준 날짜를 입력해주세요."
        return True, ""