"""
attendance_tool/main.py
프로그램 진입점: 모든 모듈을 연결하여 근태 자동 입력 실행
"""

import traceback
import tkinter as tk
from tkinter import messagebox
from datetime import datetime, timedelta

from config import (
    YEOJU_BLOCKS, SMC_BLOCKS,
    CLEAR_RANGES_YEOJU, CLEAR_RANGES_SMC
)
from models import FileConfig
from data_processor import load_and_process_data
from excel_handler import prepare_attendance_sheet, fill_attendance_file
from utils import log, today_sheet_name
from gui import create_gui


class AttendanceProcessor:
    """근태 처리 메인 클래스"""

    def __init__(self):
        """초기화"""
        pass

    def process(self, file_config: FileConfig, logbox: tk.Text):
        """
        전체 근태 처리 프로세스 실행

        Args:
            file_config: 파일 설정 정보
            logbox: 로그 출력용 Text 위젯
        """
        try:
            # === 1단계: 기준 날짜 파싱 ===
            if file_config.base_date_str:
                base_date = datetime.strptime(
                    file_config.base_date_str, "%Y-%m-%d"
                ).date()
            else:
                base_date = datetime.today().date()

            yesterday = base_date - timedelta(days=1)

            log(logbox, "=" * 60)
            log(logbox, f"근태 자동 입력 시작", base_date=base_date)
            log(logbox, f"기준 날짜: {base_date} (전일: {yesterday})")
            log(logbox, "=" * 60)

            # === 2단계: 원시 데이터 로드 ===
            log(logbox, f"[1단계] 원시 파일 읽기", base_date=base_date)
            log(logbox, f"  파일: {file_config.raw_file}")

            today_map, yesterday_map = load_and_process_data(
                file_config.raw_file, base_date
            )

            log(logbox, f"  오늘 데이터: {len(today_map)}명", base_date=base_date)
            log(logbox, f"  전일 데이터: {len(yesterday_map)}명", base_date=base_date)
            log(logbox, "  ✓ 데이터 로드 완료", base_date=base_date)

            # === 3단계: 여주 근태표 처리 ===
            log(logbox, f"\n[2단계] 여주 근태표 처리", base_date=base_date)
            log(logbox, f"  파일: {file_config.yeoju_file}")

            # 시트 이름 생성
            sheet_name = today_sheet_name()

            # 시트 준비 (복사 + 기존 데이터 지우기)
            log(logbox, f"  시트 준비 중: '{sheet_name}'", base_date=base_date)
            prepare_attendance_sheet(
                file_config.yeoju_file,
                sheet_name,
                CLEAR_RANGES_YEOJU
            )

            # 출퇴근 데이터 채우기
            log(logbox, f"  출퇴근 데이터 입력 중...", base_date=base_date)
            fill_attendance_file(
                file_config.yeoju_file,
                sheet_name,
                YEOJU_BLOCKS,
                today_map,
                yesterday_map,
                logbox
            )
            log(logbox, f"  ✓ 여주 근태표 업데이트 완료", base_date=base_date)

            # === 4단계: SMC 근태표 처리 ===
            log(logbox, f"\n[3단계] SMC 근태표 처리", base_date=base_date)
            log(logbox, f"  파일: {file_config.smc_file}")

            # 시트 준비
            log(logbox, f"  시트 준비 중: '{sheet_name}'", base_date=base_date)
            prepare_attendance_sheet(
                file_config.smc_file,
                sheet_name,
                CLEAR_RANGES_SMC
            )

            # 출퇴근 데이터 채우기
            log(logbox, f"  출퇴근 데이터 입력 중...", base_date=base_date)
            fill_attendance_file(
                file_config.smc_file,
                sheet_name,
                SMC_BLOCKS,
                today_map,
                yesterday_map,
                logbox
            )
            log(logbox, f"  ✓ SMC 근태표 업데이트 완료", base_date=base_date)

            # === 완료 ===
            log(logbox, "\n" + "=" * 60)
            log(logbox, "✓ 모든 작업이 성공적으로 완료되었습니다!", base_date=base_date)
            log(logbox, "=" * 60)

            messagebox.showinfo("완료", "근태 업데이트가 완료되었습니다.")

        except Exception as e:
            # 에러 발생 시 로그 출력
            log(logbox, "\n" + "=" * 60)
            log(logbox, "❌ 오류 발생!")
            log(logbox, "=" * 60)
            log(logbox, str(e))
            log(logbox, "\n상세 오류 정보:")
            log(logbox, traceback.format_exc())

            messagebox.showerror("오류", f"처리 중 오류가 발생했습니다:\n{str(e)}")


def main():
    """프로그램 메인 함수"""
    # 근태 처리기 생성
    processor = AttendanceProcessor()

    # GUI 생성 (실행 버튼 클릭 시 processor.process 호출)
    gui = create_gui(on_run_callback=processor.process)

    # GUI 실행
    gui.run()


if __name__ == "__main__":
    main()