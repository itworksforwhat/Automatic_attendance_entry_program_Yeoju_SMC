# .xls 파일 처리 가이드

## 📋 개요

프로그램이 .xls 파일(구 Excel 형식)을 **자동으로 .xlsx로 변환**하여 처리합니다.
더 이상 수동으로 변환할 필요가 없습니다!

---

## ✨ 자동 변환 기능

### 작동 방식
1. .xls 파일 선택
2. 프로그램이 자동으로 여러 방법 시도
3. 변환 성공 시 자동으로 처리
4. 임시 파일은 자동 삭제

### 변환 방법 우선순위
```
1순위: Windows Excel COM (가장 정확)
   ↓ 실패 시
2순위: xlrd + xlsxwriter
   ↓ 실패 시
3순위: pandas 변환
   ↓ 모두 실패 시
수동 변환 안내
```

---

## 🚀 권장 설정

### Windows 사용자 (권장)
```bash
pip install pywin32
```

**장점:**
- Excel COM 사용으로 가장 정확한 변환
- 모든 서식, 수식 보존
- 빠른 처리 속도

### 모든 플랫폼
```bash
pip install xlrd==1.2.0 xlsxwriter
```

**장점:**
- Windows, macOS, Linux 모두 사용 가능
- 추가 소프트웨어 불필요

### 패키지 없이 사용
아무것도 설치하지 않아도 됩니다!
- 변환 실패 시 친절한 안내 메시지 표시
- Excel에서 수동 변환 방법 안내

---

## 📊 사용 예시

### 예시 1: pywin32 설치된 경우
```
[INFO] 파일 로딩 중: C:/data/12.22.xls
[INFO] .xls 파일 감지 - 자동 변환 시도
[INFO] Excel COM을 사용하여 변환 시도: C:/data/12.22.xls
[SUCCESS] 변환 완료: C:/data/12.22_temp.xlsx
[INFO] 변환된 파일 사용: C:/data/12.22_temp.xlsx
[INFO] 파일 로딩 완료: 150행
[DEBUG] 임시 파일 삭제: C:/data/12.22_temp.xlsx
```

### 예시 2: xlrd 설치된 경우
```
[INFO] 파일 로딩 중: C:/data/12.22.xls
[INFO] .xls 파일 감지 - 자동 변환 시도
[DEBUG] win32com 모듈을 찾을 수 없음
[INFO] xlrd + xlsxwriter로 변환 시도: C:/data/12.22.xls
[SUCCESS] 변환 완료: C:/data/12.22_temp.xlsx
[INFO] 변환된 파일 사용: C:/data/12.22_temp.xlsx
[INFO] 파일 로딩 완료: 150행
```

### 예시 3: 패키지 없는 경우
```
[INFO] 파일 로딩 중: C:/data/12.22.xls
[INFO] .xls 파일 감지 - 자동 변환 시도
[DEBUG] win32com 모듈을 찾을 수 없음
[DEBUG] 필요한 모듈을 찾을 수 없음: No module named 'xlrd'
[WARNING] pandas 변환 실패: ...
[ERROR] 모든 변환 방법이 실패했습니다.

다음 중 하나를 시도해주세요:
1. pip install pywin32 (Windows)
2. pip install xlrd==1.2.0 xlsxwriter
3. Excel에서 수동으로 .xlsx로 저장
```

---

## 🔧 설치 방법 상세

### Windows 사용자 (최고 성능)

#### 방법 1: pip 설치
```bash
pip install pywin32
```

#### 방법 2: 설치 확인
```python
python -c "import win32com.client; print('pywin32 설치 완료')"
```

#### 주의사항
- Python이 관리자 권한으로 설치되어야 함
- 경로에 공백이나 한글 없어야 함

### 크로스 플랫폼 (Windows, macOS, Linux)

```bash
# xlrd 1.2.0 설치 (중요: 2.0 이상은 .xls 미지원)
pip install xlrd==1.2.0

# xlsxwriter 설치
pip install xlsxwriter
```

---

## 💡 문제 해결

### 문제 1: "No module named 'win32com'"
**원인:** pywin32가 설치되지 않음

**해결:**
```bash
pip install pywin32

# 또는 관리자 권한으로
python -m pip install pywin32
```

### 문제 2: "ModuleNotFoundError: No module named 'xlrd'"
**원인:** xlrd가 설치되지 않음

**해결:**
```bash
pip install xlrd==1.2.0
```

### 문제 3: 모든 변환 방법 실패
**원인:** 필요한 패키지가 모두 없음

**해결 (3가지 중 선택):**

#### 옵션 A: 패키지 설치 (권장)
```bash
# Windows
pip install pywin32

# 기타 OS
pip install xlrd==1.2.0 xlsxwriter
```

#### 옵션 B: 수동 변환
1. Excel에서 .xls 파일 열기
2. "다른 이름으로 저장"
3. 형식: "Excel 통합 문서 (*.xlsx)"
4. 저장
5. 프로그램에서 .xlsx 파일 선택

#### 옵션 C: 일괄 변환 스크립트 사용
별도 제공된 `batch_convert_xls.py` 실행:
```bash
python batch_convert_xls.py
```

---

## 🎯 최적의 설정

### 상황별 권장 설정

#### 회사/업무용 (Windows)
```bash
pip install pywin32
```
→ 가장 정확하고 빠름

#### 개인/가정용
```bash
pip install xlrd==1.2.0 xlsxwriter
```
→ 안정적이고 범용적

#### 일회성 사용
패키지 설치 없이 수동 변환
→ 가장 간단

---

## 📝 변환 후 파일 관리

### 임시 파일
- 자동 생성: `원본파일_temp.xlsx`
- 자동 삭제: 처리 완료 후
- 원본 유지: .xls 파일은 그대로 보존

### 영구 변환 (선택사항)
.xls 파일을 영구적으로 .xlsx로 변환하려면:
```python
from xls_converter import convert_xls_to_xlsx

# 영구 변환
convert_xls_to_xlsx("12.22.xls", "12.22.xlsx")
```

---

## ⚠️ 주의사항

### 지원하지 않는 기능
- Excel 매크로 (.xlsm)
- 암호로 보호된 파일
- 매우 큰 파일 (100MB 이상)

### 권장사항
1. **가능하면 .xlsx 사용**: 최신 형식 권장
2. **정기 백업**: 원본 파일 항상 보관
3. **테스트 실행**: 중요 데이터는 먼저 테스트

---

## 🚀 성능 비교

| 방법 | 속도 | 정확도 | 플랫폼 | 권장도 |
|------|------|--------|--------|--------|
| pywin32 | ⭐⭐⭐ | ⭐⭐⭐ | Windows | ⭐⭐⭐ |
| xlrd+xlsxwriter | ⭐⭐ | ⭐⭐ | 모두 | ⭐⭐ |
| pandas | ⭐ | ⭐⭐ | 모두 | ⭐ |
| 수동 변환 | ⭐⭐⭐ | ⭐⭐⭐ | 모두 | ⭐ |

---

## 📞 추가 도움

자동 변환이 계속 실패하면:
1. 로그 창의 에러 메시지 확인
2. Python 버전 확인 (`python --version`)
3. 패키지 버전 확인 (`pip list`)
4. 파일 경로에 특수문자/한글 확인

더 자세한 정보는 INSTALLATION_GUIDE.md를 참조하세요.
