"""
attendance_tool/excel_handler.py
엑셀 파일 처리: 시트 생성, 셀 값 쓰기, 범위 지우기
"""

from openpyxl import load_workbook
from openpyxl.utils import range_boundaries
from typing import List, Tuple, Dict, Optional
import tkinter as tk
from utils import log
from attendance_logic import decide_io


class ExcelHandler:
    """엑셀 파일 처리 클래스"""

    def __init__(self, file_path: str):
        """
        초기화

        Args:
            file_path: 엑셀 파일 경로
        """
        self.file_path = file_path
        self.workbook = None
        self.worksheet = None

    def load(self):
        """엑셀 파일 로드"""
        self.workbook = load_workbook(self.file_path)

    def save(self):
        """엑셀 파일 저장"""
        if self.workbook:
            self.workbook.save(self.file_path)

    def close(self):
        """엑셀 파일 닫기"""
        if self.workbook:
            self.workbook.close()
            self.workbook = None

    def copy_last_sheet(self, new_sheet_name: str):
        """
        마지막 시트를 복사하여 새 시트 생성

        Args:
            new_sheet_name: 새로 만들 시트 이름

        Returns:
            str: 생성된 시트 이름
        """
        if not self.workbook:
            self.load()

        # 마지막 시트 가져오기
        last_sheet = self.workbook.worksheets[-1]

        # 같은 이름의 시트가 이미 있으면 그대로 사용
        if last_sheet.title == new_sheet_name:
            self.worksheet = last_sheet
        else:
            # 시트 복사
            self.worksheet = self.workbook.copy_worksheet(last_sheet)
            self.worksheet.title = new_sheet_name

        return new_sheet_name

    def clear_ranges(self, ranges: List[str]):
        """
        지정된 셀 범위들의 값을 모두 지움

        Args:
            ranges: 지울 셀 범위 리스트 (예: ["D9:E11", "G9:G11"])
        """
        if not self.worksheet:
            raise ValueError("워크시트가 선택되지 않았습니다.")

        for rng in ranges:
            # 범위 내 모든 셀의 값을 None으로 설정
            for row in self.worksheet[rng]:
                for cell in row:
                    cell.value = None

    def fill_attendance_blocks(
            self,
            sheet_name: str,
            blocks: List[Tuple[str, str, str]],
            today_map: Dict,
            yesterday_map: Dict,
            logbox: Optional[tk.Text] = None
    ):
        """
        근태표의 각 블록에 출퇴근 시간을 채움

        Args:
            sheet_name: 시트 이름
            blocks: [(이름범위, 출근범위, 퇴근범위), ...]
            today_map: 오늘 데이터 맵
            yesterday_map: 전일 데이터 맵
            logbox: 로그 출력용 Text 위젯
        """
        if not self.workbook:
            self.load()

        # 시트 선택
        self.worksheet = self.workbook[sheet_name]

        # 각 블록 처리
        for name_range, check_in_range, check_out_range in blocks:
            # 셀 범위의 경계 좌표 추출
            n_min_col, n_min_row, n_max_col, n_max_row = range_boundaries(name_range)
            i_min_col, i_min_row, _, _ = range_boundaries(check_in_range)
            o_min_col, o_min_row, _, _ = range_boundaries(check_out_range)

            # 이름 범위의 각 행 처리
            for row in range(n_min_row, n_max_row + 1):
                # 이름 셀 읽기
                name_cell = self.worksheet.cell(row=row, column=n_min_col)
                name = name_cell.value

                # 이름이 없으면 건너뛰기
                if not name:
                    continue

                # 이름 정리 (공백 제거)
                name_key = str(name).strip()

                # 출퇴근 시간 결정
                check_in, check_out, base_date = decide_io(
                    name_key, today_map, yesterday_map
                )

                # 로그 출력
                if logbox:
                    log(
                        logbox,
                        f"{sheet_name} {name_range}: 행 {row}, "
                        f"이름={name_key}, 출근={check_in}, 퇴근={check_out}",
                        base_date=base_date
                    )

                # 출근/퇴근 셀 위치 계산
                check_in_row = i_min_row + (row - n_min_row)
                check_out_row = o_min_row + (row - n_min_row)

                # 출근 시각 쓰기
                in_cell = self.worksheet.cell(row=check_in_row, column=i_min_col)
                in_cell.value = check_in if check_in else None

                # 퇴근 시각 쓰기
                out_cell = self.worksheet.cell(row=check_out_row, column=o_min_col)
                out_cell.value = check_out if check_out else None


def prepare_attendance_sheet(
        file_path: str,
        sheet_name: str,
        clear_ranges: List[str]
) -> str:
    """
    근태표 시트 준비: 마지막 시트 복사 + 지정 범위 값 지우기

    Args:
        file_path: 엑셀 파일 경로
        sheet_name: 새 시트 이름
        clear_ranges: 지울 셀 범위 리스트

    Returns:
        str: 생성된 시트 이름
    """
    handler = ExcelHandler(file_path)

    try:
        # 파일 로드
        handler.load()

        # 시트 복사
        created_name = handler.copy_last_sheet(sheet_name)

        # 범위 지우기
        handler.clear_ranges(clear_ranges)

        # 저장 및 닫기
        handler.save()
        handler.close()

        return created_name

    except Exception as e:
        # 에러 발생 시 파일 닫기
        handler.close()
        raise e


def fill_attendance_file(
        file_path: str,
        sheet_name: str,
        blocks: List[Tuple[str, str, str]],
        today_map: Dict,
        yesterday_map: Dict,
        logbox: Optional[tk.Text] = None
):
    """
    근태 파일에 출퇴근 시간 채우기

    Args:
        file_path: 엑셀 파일 경로
        sheet_name: 시트 이름
        blocks: [(이름범위, 출근범위, 퇴근범위), ...]
        today_map: 오늘 데이터 맵
        yesterday_map: 전일 데이터 맵
        logbox: 로그 출력용 Text 위젯
    """
    handler = ExcelHandler(file_path)

    try:
        # 출퇴근 데이터 채우기
        handler.fill_attendance_blocks(
            sheet_name, blocks, today_map, yesterday_map, logbox
        )

        # 저장 및 닫기
        handler.save()
        handler.close()

    except Exception as e:
        # 에러 발생 시 파일 닫기
        handler.close()
        raise e