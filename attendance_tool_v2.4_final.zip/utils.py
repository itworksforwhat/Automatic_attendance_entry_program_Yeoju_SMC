"""
attendance_tool/utils.py
공통 유틸리티 함수: 로그, 날짜/시간 처리 등
"""

import tkinter as tk
from datetime import datetime
import pandas as pd
from config import SHEET_NAME_FORMAT, TIME_FORMAT


def log(text_widget: tk.Text, msg: str, base_date=None):
    """
    GUI 로그창에 메시지를 출력합니다.

    Args:
        text_widget: Tkinter Text 위젯
        msg: 출력할 메시지
        base_date: 날짜 정보 (있으면 메시지 앞에 표시)
    """
    # 날짜가 있으면 [YYYY-MM-DD] 형식으로 앞에 추가 (NaT 안전)
    prefix = ""
    if base_date is not None:
        try:
            # pandas NaT 체크
            if not pd.isna(base_date) and hasattr(base_date, "strftime"):
                d_str = base_date.strftime("%Y-%m-%d")
                prefix = f"[{d_str}] "
        except:
            # 일반 date 객체인 경우
            if hasattr(base_date, "strftime"):
                try:
                    d_str = base_date.strftime("%Y-%m-%d")
                    prefix = f"[{d_str}] "
                except:
                    pass  # strftime 실패 시 무시

    # 로그 창에 메시지 추가
    text_widget.insert(tk.END, prefix + msg + "\n")
    text_widget.see(tk.END)  # 자동 스크롤
    text_widget.update()  # 즉시 화면 갱신


def today_sheet_name() -> str:
    """
    오늘 날짜로 시트 이름을 생성합니다.

    Returns:
        str: 시트 이름 (예: '25.12.22')
    """
    return datetime.today().strftime(SHEET_NAME_FORMAT)


def extract_time_str(raw) -> str:
    """
    다양한 형식의 시간 데이터를 'HH:MM' 형식 문자열로 변환합니다.

    Args:
        raw: datetime, Timestamp, 또는 문자열 형식의 시간 데이터

    Returns:
        str: 'HH:MM' 형식의 시간 문자열 (변환 실패 시 빈 문자열)
    """
    # None이나 NaN인 경우
    if pd.isna(raw):
        return ""

    # datetime 또는 Timestamp 객체인 경우
    if isinstance(raw, (pd.Timestamp, datetime)):
        h = raw.hour
        m = raw.minute
        return f"{h:02d}:{m:02d}"

    # 문자열인 경우
    s = str(raw).strip()
    if not s:
        return ""

    # 문자열을 datetime으로 파싱 시도
    try:
        dt = pd.to_datetime(s, errors="raise")
        h = dt.hour
        m = dt.minute
        return f"{h:02d}:{m:02d}"
    except Exception:
        # 파싱 실패 시 빈 문자열 반환
        return ""


def parse_time_hour(time_str: str) -> int:
    """
    'HH:MM' 형식의 시간 문자열에서 시(hour)만 추출합니다.

    Args:
        time_str: 'HH:MM' 형식의 시간 문자열

    Returns:
        int: 시간 (0-23), 실패 시 -1
    """
    try:
        return int(time_str.split(":")[0])
    except Exception:
        return -1