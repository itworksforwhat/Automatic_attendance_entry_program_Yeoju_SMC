"""
attendance_tool/batch_convert_xls.py
여러 .xls 파일을 .xlsx로 일괄 변환하는 스크립트
"""

import os
import glob
from xls_converter import XlsConverter
from logger import Logger


def batch_convert_xls_files(directory: str = ".", pattern: str = "*.xls"):
    """
    특정 디렉토리의 모든 .xls 파일을 .xlsx로 변환

    Args:
        directory: 검색할 디렉토리 (기본값: 현재 디렉토리)
        pattern: 파일 패턴 (기본값: *.xls)
    """
    # 로거 초기화
    logger = Logger()
    converter = XlsConverter(logger)

    # 시작 메시지
    logger.section(".xls 파일 일괄 변환 시작")
    logger.info(f"디렉토리: {os.path.abspath(directory)}")
    logger.info(f"패턴: {pattern}")
    logger.separator("-")

    # .xls 파일 찾기
    search_path = os.path.join(directory, pattern)
    xls_files = glob.glob(search_path)

    if not xls_files:
        logger.warning(f".xls 파일을 찾을 수 없습니다: {search_path}")
        return

    logger.info(f"발견된 .xls 파일: {len(xls_files)}개")
    logger.separator("-")

    # 변환 통계
    success_count = 0
    fail_count = 0
    skip_count = 0

    # 각 파일 변환
    for idx, xls_file in enumerate(xls_files, 1):
        logger.info(f"\n[{idx}/{len(xls_files)}] {os.path.basename(xls_file)}")

        # 출력 파일명 생성
        xlsx_file = xls_file.replace(".xls", ".xlsx")

        # 이미 변환된 파일이 있는지 확인
        if os.path.exists(xlsx_file):
            logger.warning(f"이미 존재함 (건너뜀): {os.path.basename(xlsx_file)}")
            skip_count += 1
            continue

        # 변환 시도
        result = converter.convert(xls_file, xlsx_file)

        if result:
            success_count += 1
            logger.success(f"변환 완료: {os.path.basename(xlsx_file)}")
        else:
            fail_count += 1
            logger.error(f"변환 실패: {os.path.basename(xls_file)}")

    # 최종 요약
    logger.separator("=")
    logger.info("일괄 변환 완료")
    logger.separator("=")
    logger.info(f"총 파일: {len(xls_files)}개")
    logger.success(f"성공: {success_count}개")
    
    if skip_count > 0:
        logger.warning(f"건너뜀: {skip_count}개")
    
    if fail_count > 0:
        logger.error(f"실패: {fail_count}개")
    
    logger.separator("=")

    # 실패한 파일 처리 안내
    if fail_count > 0:
        logger.info("\n실패한 파일 처리 방법:")
        logger.info("1. pip install pywin32 (Windows)")
        logger.info("2. pip install xlrd==1.2.0 xlsxwriter")
        logger.info("3. Excel에서 수동으로 변환")


def main():
    """메인 함수 - 사용자 입력 받아 실행"""
    print("=" * 60)
    print("  .xls 파일 일괄 변환 도구")
    print("=" * 60)
    print()

    # 디렉토리 입력
    directory = input("변환할 파일이 있는 폴더 경로 (엔터=현재 폴더): ").strip()
    if not directory:
        directory = "."

    # 디렉토리 존재 확인
    if not os.path.exists(directory):
        print(f"\n❌ 폴더를 찾을 수 없습니다: {directory}")
        return

    # 확인
    print(f"\n📁 폴더: {os.path.abspath(directory)}")
    confirm = input("이 폴더의 모든 .xls 파일을 변환하시겠습니까? (y/n): ").strip().lower()

    if confirm != 'y':
        print("취소되었습니다.")
        return

    print()
    
    # 변환 실행
    batch_convert_xls_files(directory)

    print("\n변환이 완료되었습니다!")
    input("\n엔터 키를 눌러 종료...")


if __name__ == "__main__":
    main()
