"""
attendance_tool/data_processor.py
원시 출퇴근 데이터 처리: 파일 읽기, 날짜별 분리, 맵 생성
"""

import pandas as pd
from datetime import datetime, timedelta
from typing import Tuple, Dict
from config import COL_DATE, COL_NAME, COL_IN_RAW, COL_OUT_RAW
from utils import extract_time_str


class DataProcessor:
    """원시 출퇴근 데이터를 처리하는 클래스"""

    def __init__(self, file_path: str, base_date: datetime.date):
        """
        초기화

        Args:
            file_path: 원시 출퇴근 파일 경로
            base_date: 기준 날짜
        """
        self.file_path = file_path
        self.base_date = base_date
        self.yesterday = base_date - timedelta(days=1)
        self.df_today = None  # 오늘 데이터 DataFrame
        self.df_yesterday = None  # 전일 데이터 DataFrame

    def load_file(self) -> pd.DataFrame:
        """
        엑셀 파일을 읽어 DataFrame으로 반환

        Returns:
            pd.DataFrame: 원시 데이터
        """
        # .xls와 .xlsx 파일 구분하여 읽기
        if self.file_path.lower().endswith(".xls"):
            df = pd.read_excel(self.file_path, engine="xlrd")
        else:
            df = pd.read_excel(self.file_path)

        return df

    def parse_datetime_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        날짜/시간 컬럼을 datetime 형식으로 변환

        Args:
            df: 원본 DataFrame

        Returns:
            pd.DataFrame: 변환된 DataFrame
        """
        df[COL_DATE] = pd.to_datetime(df[COL_DATE])
        df[COL_IN_RAW] = pd.to_datetime(df[COL_IN_RAW])
        df[COL_OUT_RAW] = pd.to_datetime(df[COL_OUT_RAW])
        return df

    def split_by_date(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        DataFrame을 오늘 데이터와 전일 데이터로 분리

        Args:
            df: 전체 DataFrame

        Returns:
            (오늘 데이터, 전일 데이터)
        """
        # 기준 날짜에 해당하는 행 필터링
        df_today = df[df[COL_DATE].dt.date == self.base_date].copy()

        # 전일 날짜에 해당하는 행 필터링
        df_yesterday = df[df[COL_DATE].dt.date == self.yesterday].copy()

        return df_today, df_yesterday

    def add_time_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        시간 정보를 추출하여 새로운 컬럼 추가

        Args:
            df: DataFrame

        Returns:
            pd.DataFrame: 컬럼이 추가된 DataFrame
        """
        # 출근/퇴근 시각을 'HH:MM' 문자열로 변환
        df["출근시각"] = df[COL_IN_RAW].apply(extract_time_str)
        df["퇴근시각"] = df[COL_OUT_RAW].apply(extract_time_str)

        # 출근/퇴근 날짜 (date만 추출)
        df["출근일자"] = df[COL_IN_RAW].dt.date
        df["퇴근일자"] = df[COL_OUT_RAW].dt.date

        return df

    def process(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        전체 처리 프로세스 실행

        Returns:
            (오늘 데이터, 전일 데이터)
        """
        # 1. 파일 읽기
        df = self.load_file()

        # 2. 날짜/시간 컬럼 파싱
        df = self.parse_datetime_columns(df)

        # 3. 오늘/전일 데이터 분리
        df_today, df_yesterday = self.split_by_date(df)

        # 4. 시간 정보 추가
        df_today = self.add_time_columns(df_today)
        df_yesterday = self.add_time_columns(df_yesterday)

        # 인스턴스 변수에 저장
        self.df_today = df_today
        self.df_yesterday = df_yesterday

        return df_today, df_yesterday

    @staticmethod
    def build_attendance_map(df: pd.DataFrame) -> Dict[str, dict]:
        """
        DataFrame을 이름 기준 딕셔너리로 변환

        Args:
            df: 출퇴근 데이터 DataFrame

        Returns:
            dict: {이름: {출근시각, 퇴근시각, 출근일자, 퇴근일자}}
        """
        attendance_map = {}

        for _, row in df.iterrows():
            # 이름을 키로 사용 (공백 제거)
            name = str(row[COL_NAME]).strip()

            # 출퇴근 정보를 딕셔너리로 저장
            attendance_map[name] = {
                "출근시각": row["출근시각"],
                "퇴근시각": row["퇴근시각"],
                "출근일자": row["출근일자"],
                "퇴근일자": row["퇴근일자"],
            }

        return attendance_map


def load_and_process_data(file_path: str, base_date: datetime.date) -> Tuple[Dict, Dict]:
    """
    편의 함수: 파일 읽기부터 맵 생성까지 한 번에 처리

    Args:
        file_path: 원시 출퇴근 파일 경로
        base_date: 기준 날짜

    Returns:
        (오늘 맵, 전일 맵)
    """
    # 데이터 처리
    processor = DataProcessor(file_path, base_date)
    df_today, df_yesterday = processor.process()

    # 이름 기준 맵 생성
    today_map = processor.build_attendance_map(df_today)
    yesterday_map = processor.build_attendance_map(df_yesterday)

    return today_map, yesterday_map