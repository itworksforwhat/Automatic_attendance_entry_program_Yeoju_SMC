"""
attendance_tool/xls_converter.py
.xls 파일을 .xlsx로 자동 변환하는 유틸리티
"""

import os
import shutil
from typing import Optional
from logger import Logger


class XlsConverter:
    """
    .xls 파일을 .xlsx로 변환하는 클래스
    xlrd가 없어도 pywin32 또는 다른 방법으로 변환 시도
    """

    def __init__(self, logger: Optional[Logger] = None):
        """
        초기화

        Args:
            logger: 로거 인스턴스
        """
        self.logger = logger or Logger()

    def convert_with_win32com(self, xls_path: str, xlsx_path: str) -> bool:
        """
        Windows Excel COM을 사용하여 변환 (Windows 전용)

        Args:
            xls_path: 원본 .xls 파일 경로
            xlsx_path: 변환될 .xlsx 파일 경로

        Returns:
            bool: 성공 시 True
        """
        try:
            import win32com.client
            
            self.logger.info(f"Excel COM을 사용하여 변환 시도: {xls_path}")
            
            # 절대 경로로 변환
            xls_path = os.path.abspath(xls_path)
            xlsx_path = os.path.abspath(xlsx_path)
            
            # Excel 애플리케이션 시작
            excel = win32com.client.Dispatch("Excel.Application")
            excel.Visible = False
            excel.DisplayAlerts = False
            
            try:
                # 파일 열기
                workbook = excel.Workbooks.Open(xls_path)
                
                # .xlsx 형식으로 저장 (51 = xlOpenXMLWorkbook)
                workbook.SaveAs(xlsx_path, FileFormat=51)
                
                # 파일 닫기
                workbook.Close(SaveChanges=False)
                
                self.logger.success(f"변환 완료: {xlsx_path}")
                return True
                
            finally:
                # Excel 종료
                excel.Quit()
                
        except ImportError:
            self.logger.debug("win32com 모듈을 찾을 수 없음")
            return False
        except Exception as e:
            self.logger.warning(f"Excel COM 변환 실패: {str(e)}")
            return False

    def convert_with_xlrd_xlsxwriter(self, xls_path: str, xlsx_path: str) -> bool:
        """
        xlrd와 xlsxwriter를 사용하여 변환

        Args:
            xls_path: 원본 .xls 파일 경로
            xlsx_path: 변환될 .xlsx 파일 경로

        Returns:
            bool: 성공 시 True
        """
        try:
            import xlrd
            import xlsxwriter
            
            self.logger.info(f"xlrd + xlsxwriter로 변환 시도: {xls_path}")
            
            # .xls 파일 읽기
            workbook_xls = xlrd.open_workbook(xls_path, formatting_info=True)
            
            # .xlsx 파일 생성
            workbook_xlsx = xlsxwriter.Workbook(xlsx_path)
            
            # 모든 시트 복사
            for sheet_index in range(workbook_xls.nsheets):
                sheet_xls = workbook_xls.sheet_by_index(sheet_index)
                sheet_xlsx = workbook_xlsx.add_worksheet(sheet_xls.name)
                
                # 모든 행과 열 복사
                for row in range(sheet_xls.nrows):
                    for col in range(sheet_xls.ncols):
                        cell_value = sheet_xls.cell_value(row, col)
                        sheet_xlsx.write(row, col, cell_value)
            
            workbook_xlsx.close()
            
            self.logger.success(f"변환 완료: {xlsx_path}")
            return True
            
        except ImportError as e:
            self.logger.debug(f"필요한 모듈을 찾을 수 없음: {str(e)}")
            return False
        except Exception as e:
            self.logger.warning(f"xlrd 변환 실패: {str(e)}")
            return False

    def convert_with_pandas(self, xls_path: str, xlsx_path: str) -> bool:
        """
        pandas를 사용하여 변환

        Args:
            xls_path: 원본 .xls 파일 경로
            xlsx_path: 변환될 .xlsx 파일 경로

        Returns:
            bool: 성공 시 True
        """
        try:
            import pandas as pd
            
            self.logger.info(f"pandas로 변환 시도: {xls_path}")
            
            # 모든 시트 읽기
            all_sheets = pd.read_excel(xls_path, sheet_name=None, engine='xlrd')
            
            # .xlsx로 저장
            with pd.ExcelWriter(xlsx_path, engine='openpyxl') as writer:
                for sheet_name, df in all_sheets.items():
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            self.logger.success(f"변환 완료: {xlsx_path}")
            return True
            
        except Exception as e:
            self.logger.warning(f"pandas 변환 실패: {str(e)}")
            return False

    def convert(self, xls_path: str, xlsx_path: Optional[str] = None) -> Optional[str]:
        """
        .xls 파일을 .xlsx로 변환 (여러 방법 시도)

        Args:
            xls_path: 원본 .xls 파일 경로
            xlsx_path: 변환될 .xlsx 파일 경로 (None이면 자동 생성)

        Returns:
            str: 변환된 .xlsx 파일 경로, 실패 시 None
        """
        # 출력 파일 경로 생성
        if xlsx_path is None:
            base_name = os.path.splitext(xls_path)[0]
            xlsx_path = f"{base_name}.xlsx"
        
        self.logger.info("=" * 60)
        self.logger.info(f".xls → .xlsx 자동 변환 시작")
        self.logger.info(f"원본: {xls_path}")
        self.logger.info(f"대상: {xlsx_path}")
        self.logger.info("=" * 60)
        
        # 파일 존재 확인
        if not os.path.exists(xls_path):
            self.logger.error(f"파일을 찾을 수 없습니다: {xls_path}")
            return None
        
        # 이미 .xlsx 파일이 있으면 사용
        if os.path.exists(xlsx_path):
            self.logger.info(f"변환된 파일이 이미 존재합니다: {xlsx_path}")
            return xlsx_path
        
        # 방법 1: Windows Excel COM (가장 정확)
        if self.convert_with_win32com(xls_path, xlsx_path):
            return xlsx_path
        
        # 방법 2: xlrd + xlsxwriter
        if self.convert_with_xlrd_xlsxwriter(xls_path, xlsx_path):
            return xlsx_path
        
        # 방법 3: pandas
        if self.convert_with_pandas(xls_path, xlsx_path):
            return xlsx_path
        
        # 모든 방법 실패
        self.logger.error("모든 변환 방법이 실패했습니다.")
        self.logger.error("다음 중 하나를 시도해주세요:")
        self.logger.error("1. pip install pywin32 (Windows)")
        self.logger.error("2. pip install xlrd==1.2.0 xlsxwriter")
        self.logger.error("3. Excel에서 수동으로 .xlsx로 저장")
        
        return None


def convert_xls_to_xlsx(
        xls_path: str,
        xlsx_path: Optional[str] = None,
        logger: Optional[Logger] = None
) -> Optional[str]:
    """
    .xls 파일을 .xlsx로 변환하는 편의 함수

    Args:
        xls_path: 원본 .xls 파일 경로
        xlsx_path: 변환될 .xlsx 파일 경로 (None이면 자동 생성)
        logger: 로거 인스턴스

    Returns:
        str: 변환된 .xlsx 파일 경로, 실패 시 None
    """
    converter = XlsConverter(logger)
    return converter.convert(xls_path, xlsx_path)
