"""
attendance_tool/excel_handler.py (개선 버전)
엑셀 파일 처리: 시트 생성, 셀 값 쓰기, 범위 지우기
"""

from openpyxl import load_workbook
from openpyxl.utils import range_boundaries
from typing import List, Tuple, Dict, Optional
import tkinter as tk
from attendance_logic import decide_io
from validators import FileValidator
from exceptions import SheetNotFoundError, InvalidFileFormatError
from logger import Logger, LogLevel


class ExcelHandler:
    """엑셀 파일 처리 클래스 (개선 버전)"""

    def __init__(self, file_path: str, logger: Optional[Logger] = None):
        """
        초기화

        Args:
            file_path: 엑셀 파일 경로
            logger: 로거 인스턴스
        """
        self.file_path = file_path
        self.workbook = None
        self.worksheet = None
        self.logger = logger or Logger()

    def validate_file(self):
        """파일 검증"""
        try:
            FileValidator.validate_all(self.file_path)
        except Exception as e:
            self.logger.error(f"파일 검증 실패: {str(e)}")
            raise

    def load(self):
        """
        엑셀 파일 로드 (개선된 에러 처리)

        Raises:
            InvalidFileFormatError: 파일 로드 실패 시
        """
        try:
            self.validate_file()
            self.logger.debug(f"엑셀 파일 로딩: {self.file_path}")
            self.workbook = load_workbook(self.file_path)
            self.logger.debug(f"엑셀 파일 로딩 완료 (시트 수: {len(self.workbook.worksheets)})")

        except Exception as e:
            self.logger.error(f"엑셀 파일 로딩 실패: {str(e)}")
            raise InvalidFileFormatError(
                self.file_path,
                "Excel 파일",
                str(e)
            )

    def save(self):
        """
        엑셀 파일 저장 (개선된 에러 처리)

        Raises:
            Exception: 저장 실패 시
        """
        if not self.workbook:
            self.logger.error("저장할 워크북이 없습니다.")
            raise ValueError("워크북이 로드되지 않았습니다.")

        try:
            self.logger.debug(f"엑셀 파일 저장 중: {self.file_path}")
            self.workbook.save(self.file_path)
            self.logger.success(f"엑셀 파일 저장 완료: {self.file_path}")

        except PermissionError:
            self.logger.error(
                f"파일이 다른 프로그램에서 열려있습니다: {self.file_path}"
            )
            raise Exception(
                f"파일 저장 실패: 파일이 다른 프로그램에서 사용 중입니다.\n"
                f"파일을 닫고 다시 시도해주세요."
            )

        except Exception as e:
            self.logger.error(f"파일 저장 실패: {str(e)}")
            raise

    def close(self):
        """엑셀 파일 닫기"""
        if self.workbook:
            self.logger.debug("엑셀 파일 닫기")
            self.workbook.close()
            self.workbook = None

    def copy_last_sheet(self, new_sheet_name: str):
        """
        마지막 시트를 복사하여 새 시트 생성 (메모 서식 보존)

        Args:
            new_sheet_name: 새로 만들 시트 이름

        Returns:
            str: 생성된 시트 이름
        """
        if not self.workbook:
            self.load()

        # 마지막 시트 가져오기
        if not self.workbook.worksheets:
            raise InvalidFileFormatError(
                self.file_path,
                "시트가 포함된 Excel 파일",
                "파일에 시트가 없습니다."
            )

        last_sheet = self.workbook.worksheets[-1]
        self.logger.debug(f"마지막 시트: '{last_sheet.title}'")

        # 같은 이름의 시트가 이미 있는지 확인
        if new_sheet_name in self.workbook.sheetnames:
            self.logger.info(f"시트 '{new_sheet_name}'이(가) 이미 존재함 - 기존 시트 사용")
            self.worksheet = self.workbook[new_sheet_name]
        else:
            # 시트 복사
            self.logger.info(f"새 시트 생성: '{new_sheet_name}'")
            self.worksheet = self.workbook.copy_worksheet(last_sheet)
            self.worksheet.title = new_sheet_name
            
            # 메모 서식 복사 (openpyxl 버그 우회)
            self._copy_comment_styles(last_sheet, self.worksheet)
            
            self.logger.success(f"시트 복사 완료: '{last_sheet.title}' → '{new_sheet_name}'")

        return new_sheet_name

    def _copy_comment_styles(self, source_sheet, target_sheet):
        """
        메모(comment)의 서식을 원본 시트에서 대상 시트로 복사
        
        Args:
            source_sheet: 원본 시트
            target_sheet: 대상 시트
        """
        try:
            from copy import copy
            
            copied_count = 0
            
            # 원본 시트의 모든 셀 순회
            for row in source_sheet.iter_rows():
                for source_cell in row:
                    # 메모가 있는 셀만 처리
                    if source_cell.comment:
                        # 대상 시트의 같은 위치 셀
                        target_cell = target_sheet[source_cell.coordinate]
                        
                        # 메모가 이미 복사되어 있다면
                        if target_cell.comment:
                            # 원본 메모의 서식 정보 복사
                            if hasattr(source_cell.comment, 'width'):
                                target_cell.comment.width = source_cell.comment.width
                            if hasattr(source_cell.comment, 'height'):
                                target_cell.comment.height = source_cell.comment.height
                            
                            # 텍스트 서식 복사 (가장 중요!)
                            if hasattr(source_cell.comment, 'text') and hasattr(target_cell.comment, 'text'):
                                # 원본 메모의 텍스트를 완전히 복사
                                target_cell.comment.text = copy(source_cell.comment.text)
                            
                            copied_count += 1
            
            if copied_count > 0:
                self.logger.debug(f"메모 서식 복사 완료: {copied_count}개")
                
        except Exception as e:
            self.logger.warning(f"메모 서식 복사 중 오류 (무시됨): {str(e)}")

    def clear_ranges(self, ranges: List[str]):
        """
        지정된 셀 범위들의 값을 모두 지움 (서식/메모 보존)

        Args:
            ranges: 지울 셀 범위 리스트 (예: ["D9:E11", "G9:G11"])
        """
        if not self.worksheet:
            raise ValueError("워크시트가 선택되지 않았습니다.")

        self.logger.debug(f"셀 범위 지우기: {len(ranges)}개 범위")
        cleared_cells = 0

        for rng in ranges:
            try:
                # 범위 내 모든 셀의 값을 None으로 설정
                # 중요: 서식, 메모, 스타일은 유지하고 값만 지움
                for row in self.worksheet[rng]:
                    for cell in row:
                        if cell.value is not None:
                            # 값만 지우고 나머지는 보존
                            cell.value = None
                            cleared_cells += 1

            except Exception as e:
                self.logger.warning(f"범위 '{rng}' 지우기 실패: {str(e)}")

        self.logger.info(f"셀 지우기 완료: {cleared_cells}개 셀")

    def fill_attendance_blocks(
            self,
            sheet_name: str,
            blocks: List[Tuple[str, str, str]],
            today_map: Dict,
            yesterday_map: Dict,
            logbox: Optional[tk.Text] = None
    ):
        """
        근태표의 각 블록에 출퇴근 시간을 채움 (개선된 에러 처리)

        Args:
            sheet_name: 시트 이름
            blocks: [(이름범위, 출근범위, 퇴근범위), ...]
            today_map: 오늘 데이터 맵
            yesterday_map: 전일 데이터 맵
            logbox: 로그 출력용 Text 위젯
        """
        if not self.workbook:
            self.load()

        # 시트 선택
        if sheet_name not in self.workbook.sheetnames:
            raise SheetNotFoundError(sheet_name, self.file_path)

        self.worksheet = self.workbook[sheet_name]
        self.logger.info(f"시트 선택: '{sheet_name}'")

        # 통계 변수
        total_processed = 0
        total_filled = 0
        total_errors = 0

        # 각 블록 처리
        for block_idx, (name_range, check_in_range, check_out_range) in enumerate(blocks, 1):
            self.logger.debug(f"블록 {block_idx}/{len(blocks)} 처리 중: {name_range}")

            try:
                # 셀 범위의 경계 좌표 추출
                n_min_col, n_min_row, n_max_col, n_max_row = range_boundaries(name_range)
                i_min_col, i_min_row, _, _ = range_boundaries(check_in_range)
                o_min_col, o_min_row, _, _ = range_boundaries(check_out_range)

                # 이름 범위의 각 행 처리
                for row in range(n_min_row, n_max_row + 1):
                    total_processed += 1

                    # 이름 셀 읽기
                    name_cell = self.worksheet.cell(row=row, column=n_min_col)
                    name = name_cell.value

                    # 이름이 없으면 건너뛰기
                    if not name:
                        continue

                    # 이름 정리 (공백 제거)
                    name_key = str(name).strip()

                    # 출퇴근 시간 결정
                    try:
                        check_in, check_out, base_date = decide_io(
                            name_key, today_map, yesterday_map
                        )

                        # 로그 출력
                        if logbox or self.logger:
                            log_msg = (
                                f"{sheet_name} {name_range}: 행 {row}, "
                                f"이름={name_key}, 출근={check_in or '없음'}, "
                                f"퇴근={check_out or '없음'}"
                            )

                            if logbox:
                                from logger import log as old_log
                                old_log(logbox, log_msg, base_date=base_date)
                            else:
                                self.logger.debug(log_msg)

                        # 출근/퇴근 셀 위치 계산
                        check_in_row = i_min_row + (row - n_min_row)
                        check_out_row = o_min_row + (row - n_min_row)

                        # 출근 시각 쓰기
                        in_cell = self.worksheet.cell(row=check_in_row, column=i_min_col)
                        in_cell.value = check_in if check_in else None

                        # 퇴근 시각 쓰기
                        out_cell = self.worksheet.cell(row=check_out_row, column=o_min_col)
                        out_cell.value = check_out if check_out else None

                        # 값이 채워진 경우 카운트
                        if check_in or check_out:
                            total_filled += 1

                    except Exception as e:
                        total_errors += 1
                        self.logger.error(
                            f"'{name_key}' 출퇴근 처리 실패 (행 {row}): {str(e)}"
                        )

            except Exception as e:
                self.logger.error(f"블록 {block_idx} 처리 실패: {str(e)}")
                total_errors += 1

        # 처리 결과 요약
        self.logger.info("-" * 60)
        self.logger.info("출퇴근 데이터 입력 완료")
        self.logger.info(f"  처리: {total_processed}개")
        self.logger.info(f"  입력: {total_filled}개")
        if total_errors > 0:
            self.logger.warning(f"  오류: {total_errors}개")
        self.logger.info("-" * 60)


def prepare_attendance_sheet(
        file_path: str,
        sheet_name: str,
        clear_ranges: List[str],
        logger: Optional[Logger] = None
) -> str:
    """
    근태표 시트 준비: 마지막 시트 복사 + 지정 범위 값 지우기 (개선 버전)

    Args:
        file_path: 엑셀 파일 경로
        sheet_name: 새 시트 이름
        clear_ranges: 지울 셀 범위 리스트
        logger: 로거 인스턴스

    Returns:
        str: 생성된 시트 이름
    """
    if logger is None:
        logger = Logger()

    handler = ExcelHandler(file_path, logger)

    try:
        # 파일 로드
        handler.load()

        # 시트 복사
        created_name = handler.copy_last_sheet(sheet_name)

        # 범위 지우기
        handler.clear_ranges(clear_ranges)

        # 저장 및 닫기
        handler.save()
        handler.close()

        return created_name

    except Exception as e:
        # 에러 발생 시 파일 닫기
        logger.error(f"시트 준비 중 오류: {str(e)}")
        handler.close()
        raise


def fill_attendance_file(
        file_path: str,
        sheet_name: str,
        blocks: List[Tuple[str, str, str]],
        today_map: Dict,
        yesterday_map: Dict,
        logbox: Optional[tk.Text] = None,
        logger: Optional[Logger] = None
):
    """
    근태 파일에 출퇴근 시간 채우기 (개선 버전)

    Args:
        file_path: 엑셀 파일 경로
        sheet_name: 시트 이름
        blocks: [(이름범위, 출근범위, 퇴근범위), ...]
        today_map: 오늘 데이터 맵
        yesterday_map: 전일 데이터 맵
        logbox: 로그 출력용 Text 위젯
        logger: 로거 인스턴스
    """
    if logger is None:
        logger = Logger()

    handler = ExcelHandler(file_path, logger)

    try:
        # 출퇴근 데이터 채우기
        handler.fill_attendance_blocks(
            sheet_name, blocks, today_map, yesterday_map, logbox
        )

        # 저장 및 닫기
        handler.save()
        handler.close()

    except Exception as e:
        # 에러 발생 시 파일 닫기
        logger.error(f"출퇴근 데이터 입력 중 오류: {str(e)}")
        handler.close()
        raise
