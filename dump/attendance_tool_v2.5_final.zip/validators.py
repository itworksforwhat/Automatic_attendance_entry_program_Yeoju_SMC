"""
attendance_tool/validators.py
데이터 검증 로직
"""

import os
import pandas as pd
from datetime import datetime
from typing import List, Dict, Tuple, Optional
from exceptions import (
    FileNotFoundError,
    InvalidFileFormatError,
    DataValidationError,
    ColumnNotFoundError
)


class FileValidator:
    """파일 검증 클래스"""

    SUPPORTED_EXTENSIONS = {'.xls', '.xlsx', '.xlsm'}

    @staticmethod
    def validate_file_exists(file_path: str) -> bool:
        """
        파일 존재 여부 확인

        Args:
            file_path: 파일 경로

        Returns:
            bool: 파일이 존재하면 True

        Raises:
            FileNotFoundError: 파일이 존재하지 않을 때
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(file_path)
        return True

    @staticmethod
    def validate_file_extension(file_path: str) -> bool:
        """
        파일 확장자 검증

        Args:
            file_path: 파일 경로

        Returns:
            bool: 유효한 확장자이면 True

        Raises:
            InvalidFileFormatError: 지원하지 않는 확장자일 때
        """
        _, ext = os.path.splitext(file_path)
        if ext.lower() not in FileValidator.SUPPORTED_EXTENSIONS:
            raise InvalidFileFormatError(
                file_path,
                f"Excel 파일 ({', '.join(FileValidator.SUPPORTED_EXTENSIONS)})",
                f"현재 확장자: {ext}"
            )
        return True

    @staticmethod
    def validate_file_readable(file_path: str) -> bool:
        """
        파일 읽기 권한 확인

        Args:
            file_path: 파일 경로

        Returns:
            bool: 읽기 가능하면 True

        Raises:
            InvalidFileFormatError: 파일을 읽을 수 없을 때
        """
        if not os.access(file_path, os.R_OK):
            raise InvalidFileFormatError(
                file_path,
                "읽기 가능한 파일",
                "파일 읽기 권한이 없습니다."
            )
        return True

    @staticmethod
    def validate_all(file_path: str) -> bool:
        """
        모든 파일 검증 수행

        Args:
            file_path: 파일 경로

        Returns:
            bool: 모든 검증을 통과하면 True
        """
        FileValidator.validate_file_exists(file_path)
        FileValidator.validate_file_extension(file_path)
        FileValidator.validate_file_readable(file_path)
        return True


class DataFrameValidator:
    """DataFrame 검증 클래스"""

    @staticmethod
    def validate_required_columns(
            df: pd.DataFrame,
            required_columns: List[str]
    ) -> bool:
        """
        필수 컬럼 존재 여부 확인

        Args:
            df: 검증할 DataFrame
            required_columns: 필수 컬럼 리스트

        Returns:
            bool: 모든 필수 컬럼이 존재하면 True

        Raises:
            ColumnNotFoundError: 필수 컬럼이 없을 때
        """
        df_columns = df.columns.tolist()

        for col in required_columns:
            if col not in df_columns:
                raise ColumnNotFoundError(col, df_columns)

        return True

    @staticmethod
    def validate_not_empty(df: pd.DataFrame, name: str = "데이터") -> bool:
        """
        DataFrame이 비어있지 않은지 확인

        Args:
            df: 검증할 DataFrame
            name: 데이터 이름 (에러 메시지용)

        Returns:
            bool: 데이터가 있으면 True

        Raises:
            DataValidationError: 데이터가 비어있을 때
        """
        if df.empty:
            raise DataValidationError(f"{name}가 비어있습니다.")
        return True

    @staticmethod
    def validate_date_range(
            df: pd.DataFrame,
            date_column: str,
            start_date: Optional[datetime] = None,
            end_date: Optional[datetime] = None
    ) -> Tuple[bool, Dict]:
        """
        날짜 범위 검증 및 통계 반환

        Args:
            df: 검증할 DataFrame
            date_column: 날짜 컬럼명
            start_date: 시작 날짜 (옵션)
            end_date: 종료 날짜 (옵션)

        Returns:
            (bool, dict): (검증 통과 여부, 통계 정보)
        """
        if date_column not in df.columns:
            return False, {"error": f"컬럼을 찾을 수 없음: {date_column}"}

        # 날짜로 변환
        dates = pd.to_datetime(df[date_column], errors='coerce')

        # NaT(Not a Time) 개수 확인
        nat_count = dates.isna().sum()

        # 날짜 범위 통계
        stats = {
            "total_rows": len(df),
            "valid_dates": len(dates) - nat_count,
            "invalid_dates": nat_count,
            "min_date": dates.min() if not dates.isna().all() else None,
            "max_date": dates.max() if not dates.isna().all() else None,
        }

        # 범위 검증 - date 타입을 datetime으로 변환
        if start_date and not dates.isna().all():
            # date 객체를 pandas Timestamp로 변환
            if hasattr(start_date, 'date'):
                # datetime 객체인 경우
                start_date_ts = pd.Timestamp(start_date)
            else:
                # date 객체인 경우
                start_date_ts = pd.Timestamp(start_date)
            
            out_of_range = (dates < start_date_ts).sum()
            stats["before_start"] = out_of_range

        if end_date and not dates.isna().all():
            # date 객체를 pandas Timestamp로 변환
            if hasattr(end_date, 'date'):
                # datetime 객체인 경우
                end_date_ts = pd.Timestamp(end_date)
            else:
                # date 객체인 경우
                end_date_ts = pd.Timestamp(end_date)
            
            out_of_range = (dates > end_date_ts).sum()
            stats["after_end"] = out_of_range

        return True, stats


class AttendanceDataValidator:
    """출퇴근 데이터 검증 클래스"""

    @staticmethod
    def validate_time_format(time_str: str) -> bool:
        """
        시간 형식 검증 (HH:MM)

        Args:
            time_str: 시간 문자열

        Returns:
            bool: 유효한 형식이면 True
        """
        if not time_str or pd.isna(time_str):
            return True  # 빈 값은 허용

        try:
            parts = str(time_str).split(":")
            if len(parts) != 2:
                return False

            hour, minute = int(parts[0]), int(parts[1])
            return 0 <= hour < 24 and 0 <= minute < 60

        except (ValueError, AttributeError):
            return False

    @staticmethod
    def validate_attendance_record(record: Dict) -> Tuple[bool, List[str]]:
        """
        출퇴근 기록의 유효성 검증

        Args:
            record: 출퇴근 기록 딕셔너리

        Returns:
            (bool, List[str]): (유효 여부, 경고 메시지 리스트)
        """
        warnings = []

        # 출근/퇴근 시각 확인
        check_in = record.get("출근시각", "")
        check_out = record.get("퇴근시각", "")

        # 시간 형식 검증
        if check_in and not AttendanceDataValidator.validate_time_format(check_in):
            warnings.append(f"출근 시각 형식 오류: {check_in}")

        if check_out and not AttendanceDataValidator.validate_time_format(check_out):
            warnings.append(f"퇴근 시각 형식 오류: {check_out}")

        # 출근만 있고 퇴근이 없는 경우
        if check_in and not check_out:
            warnings.append("퇴근 기록 없음")

        # 퇴근만 있고 출근이 없는 경우
        if check_out and not check_in:
            warnings.append("출근 기록 없음")

        # 출퇴근 날짜 확인
        check_in_date = record.get("출근일자")
        check_out_date = record.get("퇴근일자")

        # 날짜 논리 검증 (NaT 체크 추가)
        if check_in_date and check_out_date:
            # pandas의 NaT 또는 None 체크
            import pandas as pd
            
            # NaT인지 확인
            is_in_nat = pd.isna(check_in_date) if hasattr(pd, 'isna') else check_in_date is None
            is_out_nat = pd.isna(check_out_date) if hasattr(pd, 'isna') else check_out_date is None
            
            if not is_in_nat and not is_out_nat:
                from datetime import timedelta
                diff = (check_out_date - check_in_date).days

                # 퇴근이 출근보다 2일 이상 늦은 경우
                if diff > 1:
                    warnings.append(f"출퇴근 날짜 차이 비정상: {diff}일")

                # 퇴근이 출근보다 이른 경우
                if diff < 0:
                    warnings.append(f"퇴근이 출근보다 이릅니다: {diff}일")

        is_valid = len(warnings) == 0
        return is_valid, warnings

    @staticmethod
    def generate_data_quality_report(
            today_map: Dict,
            yesterday_map: Dict
    ) -> Dict:
        """
        데이터 품질 보고서 생성

        Args:
            today_map: 오늘 데이터 맵
            yesterday_map: 전일 데이터 맵

        Returns:
            dict: 데이터 품질 보고서
        """
        report = {
            "today": {
                "total": len(today_map),
                "complete": 0,  # 출퇴근 모두 있음
                "incomplete": 0,  # 출근 또는 퇴근만 있음
                "warnings": []
            },
            "yesterday": {
                "total": len(yesterday_map),
                "complete": 0,
                "incomplete": 0,
                "warnings": []
            }
        }

        # 오늘 데이터 검증
        for name, record in today_map.items():
            is_valid, warnings = AttendanceDataValidator.validate_attendance_record(record)

            if record.get("출근시각") and record.get("퇴근시각"):
                report["today"]["complete"] += 1
            elif record.get("출근시각") or record.get("퇴근시각"):
                report["today"]["incomplete"] += 1

            if warnings:
                report["today"]["warnings"].append({
                    "name": name,
                    "warnings": warnings
                })

        # 전일 데이터 검증
        for name, record in yesterday_map.items():
            is_valid, warnings = AttendanceDataValidator.validate_attendance_record(record)

            if record.get("출근시각") and record.get("퇴근시각"):
                report["yesterday"]["complete"] += 1
            elif record.get("출근시각") or record.get("퇴근시각"):
                report["yesterday"]["incomplete"] += 1

            if warnings:
                report["yesterday"]["warnings"].append({
                    "name": name,
                    "warnings": warnings
                })

        return report
