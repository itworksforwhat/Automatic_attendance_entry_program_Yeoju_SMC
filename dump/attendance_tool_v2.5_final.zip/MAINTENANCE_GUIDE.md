# 근태 자동 입력 시스템 v2.4 - 유지보수 가이드

## 📚 목차
1. [시스템 개요](#시스템-개요)
2. [프로젝트 구조](#프로젝트-구조)
3. [핵심 모듈 설명](#핵심-모듈-설명)
4. [주요 함수 설명](#주요-함수-설명)
5. [데이터 흐름](#데이터-흐름)
6. [설정 변경 방법](#설정-변경-방법)
7. [문제 해결 가이드](#문제-해결-가이드)
8. [확장 가이드](#확장-가이드)

---

## 시스템 개요

### 목적
출퇴근 원시 데이터(.xls/.xlsx)를 읽어서 여주/SMC 근태표에 자동으로 입력하는 시스템

### 주요 기능
1. .xls 파일 자동 변환
2. 주간/야간 근무 패턴 자동 판별
3. 월요일/공휴일 다음 날 전일 데이터 자동 검색
4. 미출근자 처리
5. 근태표 시트 자동 생성 및 데이터 입력

### 실행 흐름
```
원시 파일 읽기 
  ↓
.xls → .xlsx 변환 (필요시)
  ↓
데이터 파싱 및 검증
  ↓
오늘/전일 데이터 분리
  ↓
출퇴근 맵 생성
  ↓
근태표 시트 준비
  ↓
출퇴근 데이터 입력
  ↓
완료
```

---

## 프로젝트 구조

```
attendance_tool/
│
├── main_improved.py              # 메인 실행 파일
├── gui.py                        # GUI 인터페이스
│
├── config.py                     # 설정 파일 (셀 범위, 공휴일 등)
│
├── data_processor_improved.py    # 데이터 처리 핵심 로직
├── attendance_logic.py           # 출퇴근 판단 로직
├── excel_handler_improved.py     # 엑셀 파일 처리
│
├── validators.py                 # 데이터 검증
├── exceptions.py                 # 예외 정의
├── logger.py                     # 로깅 시스템
├── utils.py                      # 유틸리티 함수
├── models.py                     # 데이터 모델
│
├── xls_converter.py              # .xls → .xlsx 변환
├── batch_convert_xls.py          # 일괄 변환 도구
│
└── *.md, *.txt                   # 문서
```

---

## 핵심 모듈 설명

### 1. main_improved.py
**역할**: 프로그램의 시작점, 전체 워크플로우 관리

**주요 클래스**: `AttendanceProcessor`

**주요 메서드**:
- `process()`: 전체 처리 실행
- `load_data()`: 원시 데이터 로드
- `update_sheet()`: 근태표 업데이트

**사용 예시**:
```python
processor = AttendanceProcessor(
    base_date=datetime(2025, 12, 22).date(),
    logger=logger
)
processor.process(file_config)
```

---

### 2. config.py
**역할**: 모든 설정 값 중앙 관리

**주요 설정**:

#### 컬럼명 정의
```python
COL_DATE = "'근무일자'"      # 원시 데이터 날짜 컬럼
COL_NAME = "'이름'"          # 이름 컬럼
COL_IN_RAW = "'출근시간'"    # 출근 시간 컬럼
COL_OUT_RAW = "'퇴근시간'"   # 퇴근 시간 컬럼
```

#### 셀 범위 정의
```python
# 여주 근태표 블록
YEOJU_BLOCKS = [
    ("C9:C11", "D9:D11", "E9:E11"),  # (이름, 출근, 퇴근)
    ("J9:J18", "K9:K18", "L9:L18"),
    # ...
]

# 지울 셀 범위
CLEAR_RANGES_YEOJU = [
    "D9:E11", "G9:G11",  # 출퇴근 + 잔업
    # ...
]
```

#### 공휴일 정의
```python
HOLIDAYS_2025 = [
    "2025-01-01",  # 신정
    "2025-03-01",  # 삼일절
    # ...
]
```

**수정 방법**:
1. 셀 범위 변경: `YEOJU_BLOCKS`, `SMC_BLOCKS` 수정
2. 공휴일 추가: `HOLIDAYS_2025` 리스트에 추가
3. 컬럼명 변경: `COL_*` 상수 수정

---

### 3. data_processor_improved.py
**역할**: 데이터 로딩, 파싱, 분리의 핵심 로직

**주요 클래스**: `DataProcessor`

**주요 메서드**:

#### `__init__(file_path, base_date, logger)`
```python
"""
초기화
- file_path: 원시 엑셀 파일 경로
- base_date: 기준 날짜 (근태표 날짜)
- logger: 로거 인스턴스
"""
```

#### `load_file()`
```python
"""
엑셀 파일 로드 (.xls 자동 변환 포함)

반환값:
- pd.DataFrame: 원시 데이터

처리 과정:
1. .xls 파일 감지
2. 자동 변환 (필요시)
3. DataFrame 로드
4. 검증
"""
```

#### `split_by_date(df)`
```python
"""
데이터를 오늘/전일로 분리

특수 처리:
- 월요일: 이전 금요일 검색
- 공휴일 다음: 이전 근무일 검색

반환값:
- (df_today, df_yesterday): 튜플
"""
```

#### `is_workday(check_date)`
```python
"""
근무일 여부 판단

조건:
- 월~금 (토일 제외)
- 공휴일 제외

반환값:
- bool: 근무일이면 True
"""
```

#### `find_previous_workday(from_date, max_days=7)`
```python
"""
이전 근무일 찾기

인자:
- from_date: 시작 날짜
- max_days: 최대 검색 일수 (기본 7일)

반환값:
- date or None: 이전 근무일
"""
```

#### `build_attendance_map(df)`
```python
"""
출퇴근 맵 생성

반환값:
- dict: {이름: {출근시각, 퇴근시각, 출근일자, 퇴근일자}}

예시:
{
    "김철수": {
        "출근시각": "08:00",
        "퇴근시각": "18:00",
        "출근일자": date(2025, 12, 22),
        "퇴근일자": date(2025, 12, 22)
    }
}
"""
```

**데이터 흐름**:
```
load_file()
  ↓ DataFrame
split_by_date()
  ↓ df_today, df_yesterday
build_attendance_map() × 2
  ↓ today_map, yesterday_map
```

---

### 4. attendance_logic.py
**역할**: 출퇴근 시간 결정의 핵심 로직

**주요 클래스**: `AttendanceLogic`

**주요 메서드**:

#### `__init__(today_map, yesterday_map)`
```python
"""
초기화
- today_map: 오늘 출퇴근 맵
- yesterday_map: 전일 출퇴근 맵
"""
```

#### `is_day_shift(check_in_time, check_in_date)`
```python
"""
주간 근무 판별

기준:
- 출근 시각 0~12시 사이

반환값:
- bool: 주간 근무이면 True
"""
```

#### `is_night_shift(check_in_date, check_out_date)`
```python
"""
야간 근무 판별

기준:
- 퇴근일 = 출근일 + 1일

반환값:
- bool: 야간 근무이면 True
"""
```

#### `decide_attendance(name)` ⭐ 핵심 함수
```python
"""
직원의 출퇴근 시간 결정

처리 순서:
1. 완전 결근 체크
2. 오늘 주간 출근 체크
3. 전일 야간 근무 체크
4. 미출근 + 전일 퇴근만
5. 오늘 퇴근만
6. 전일 출근+퇴근 있고 오늘 없음 (미출근) ⭐
7. 전일 출근만
8. 기타

반환값:
- ProcessResult: (출근시각, 퇴근시각, 기준날짜, 패턴)
"""
```

**처리 케이스**:

```python
# 케이스 1: 정상 출퇴근
22일: 출근 O, 퇴근 O
→ 출근 O, 퇴근 O

# 케이스 2: 주간 근무 + 월요일
19일: 출근 O, 퇴근 O
22일: 출근 O, 퇴근 X
→ 출근 O(22일), 퇴근 O(19일)

# 케이스 3: 야간 근무
19일: 출근 O(20:00), 퇴근 X
20일: 출근 X, 퇴근 O(06:00)
→ 출근 O(19일), 퇴근 O(20일)

# 케이스 4: 미출근 (전일 퇴근 사용) ⭐ v2.4 수정
19일: 출근 O, 퇴근 O
22일: 출근 X, 퇴근 X
→ 출근 X, 퇴근 O(19일)

# 케이스 5: 미출근 (데이터 없음)
19일: 출근 O, 퇴근 X
22일: 데이터 없음
→ 출근 X, 퇴근 X
```

**편의 함수**:
```python
def decide_io(name, today_map, yest_map):
    """
    호환성 함수 (기존 코드용)
    
    반환값:
    - (출근시각, 퇴근시각, 기준날짜): 튜플
    """
```

---

### 5. excel_handler_improved.py
**역할**: 엑셀 파일 읽기/쓰기

**주요 클래스**: `ExcelHandler`

**주요 메서드**:

#### `load()`
```python
"""
엑셀 파일 로드

사용 라이브러리: openpyxl
"""
```

#### `copy_last_sheet(new_sheet_name)`
```python
"""
마지막 시트 복사

처리:
1. 마지막 시트 찾기
2. 새 시트 생성
3. 셀 값/스타일 복사
"""
```

#### `clear_ranges(ranges)`
```python
"""
지정 범위 셀 지우기

인자:
- ranges: ["D9:E11", "G9:G11", ...]

처리:
- 셀 값만 지우고 스타일 유지
"""
```

#### `write_attendance_data(blocks, today_map, yesterday_map, ...)`
```python
"""
출퇴근 데이터 입력

인자:
- blocks: [(이름범위, 출근범위, 퇴근범위), ...]
- today_map: 오늘 출퇴근 맵
- yesterday_map: 전일 출퇴근 맵

처리:
1. 각 블록 순회
2. 이름 읽기
3. 출퇴근 시간 결정 (attendance_logic 사용)
4. 셀에 쓰기
"""
```

---

### 6. validators.py
**역할**: 데이터 검증

**주요 클래스**: `FileValidator`, `DataFrameValidator`, `AttendanceDataValidator`

**주요 메서드**:

#### `FileValidator.validate_all(file_path)`
```python
"""
파일 검증

체크 항목:
1. 파일 존재 여부
2. 파일 크기 (0바이트 체크)
3. 확장자
4. 읽기 권한
"""
```

#### `DataFrameValidator.validate_dataframe(df)`
```python
"""
DataFrame 검증

체크 항목:
1. 비어있지 않음
2. 필수 컬럼 존재
3. 날짜 컬럼 형식
"""
```

#### `AttendanceDataValidator.validate_time_format(time_str)`
```python
"""
시간 형식 검증

형식: "HH:MM" (예: "08:00")

반환값:
- bool: 유효하면 True
"""
```

#### `AttendanceDataValidator.validate_attendance_record(record)`
```python
"""
출퇴근 기록 검증

체크 항목:
1. 시간 형식
2. 출근/퇴근 논리 (출근만, 퇴근만 등)
3. 날짜 논리 (NaT 안전 체크)

반환값:
- (bool, List[str]): (유효 여부, 경고 목록)
"""
```

---

### 7. xls_converter.py
**역할**: .xls → .xlsx 자동 변환

**주요 함수**:

#### `convert_xls_to_xlsx(xls_path, xlsx_path=None)`
```python
"""
.xls 파일을 .xlsx로 변환

시도 순서:
1. pywin32 (Windows Excel COM) - 가장 정확
2. xlrd + xlsxwriter - 범용
3. pandas - 기본

반환값:
- str: 변환된 .xlsx 파일 경로

예외:
- 모든 방법 실패 시 안내 메시지
"""
```

**변환 방법 선택**:
```python
if platform.system() == 'Windows':
    try:
        # 방법 1: Excel COM (가장 정확)
        excel = win32com.client.Dispatch("Excel.Application")
        # ...
    except:
        # 방법 2: xlrd + xlsxwriter
        # ...
else:
    # 방법 2 또는 3
```

---

### 8. logger.py
**역할**: 로깅 시스템

**주요 클래스**: `Logger`

**로그 레벨**:
```python
DEBUG    # 상세 정보
INFO     # 일반 정보
SUCCESS  # 성공 메시지
WARNING  # 경고
ERROR    # 오류
```

**주요 메서드**:

#### `log(message, level, base_date=None)`
```python
"""
로그 출력

형식:
HH:MM:SS [LEVEL] [날짜] 메시지

예시:
14:30:15 [INFO] [2025-12-22] 데이터 로드 완료
"""
```

#### NaT 안전 처리
```python
# pandas NaT 체크
if not pd.isna(base_date) and hasattr(base_date, "strftime"):
    date_str = base_date.strftime('%Y-%m-%d')
```

---

### 9. utils.py
**역할**: 유틸리티 함수 모음

**주요 함수**:

#### `extract_time_str(raw)`
```python
"""
다양한 형식을 HH:MM으로 변환

입력 형식:
- datetime
- pd.Timestamp
- 문자열 "2025/12/22 08:00"
- NaN

반환값:
- str: "08:00" 또는 ""
"""
```

#### `parse_time_hour(time_str)`
```python
"""
HH:MM에서 시간만 추출

입력: "08:30"
반환: 8 (int)
"""
```

#### `today_sheet_name()`
```python
"""
오늘 날짜로 시트 이름 생성

반환: "25.12.22" (YY.MM.DD)
"""
```

---

### 10. models.py
**역할**: 데이터 모델 정의

**주요 클래스**:

#### `FileConfig`
```python
"""
파일 설정 정보

속성:
- raw_file: 원시 파일 경로
- attendance_file: 근태표 파일 경로
- sheet_name: 시트 이름
- blocks: 셀 범위 블록
- clear_ranges: 지울 범위
- label: 라벨 (예: "여주")
"""
```

#### `ProcessResult`
```python
"""
출퇴근 처리 결과

속성:
- check_in: 출근 시각
- check_out: 퇴근 시각
- base_date: 기준 날짜
- pattern: 처리 패턴
"""
```

---

## 주요 함수 설명

### 데이터 로딩 함수

#### `load_and_process_data(file_path, base_date, logger)`
```python
"""
전체 데이터 로딩 및 처리

위치: data_processor_improved.py

처리 단계:
1. 파일 로드
2. 데이터 분리
3. 맵 생성
4. 품질 보고서

반환값:
- (today_map, yesterday_map): 튜플
"""
```

**사용 예시**:
```python
today_map, yesterday_map = load_and_process_data(
    file_path="12.22.xls",
    base_date=date(2025, 12, 22),
    logger=logger
)
```

---

### 엑셀 처리 함수

#### `prepare_attendance_sheet(file_path, sheet_name, clear_ranges, logger)`
```python
"""
근태표 시트 준비

위치: excel_handler_improved.py

처리:
1. 마지막 시트 복사
2. 새 시트 생성
3. 지정 범위 셀 지우기

반환값:
- str: 생성된 시트 이름
"""
```

#### `write_attendance_to_sheet(file_path, sheet_name, blocks, today_map, yesterday_map, logger)`
```python
"""
출퇴근 데이터 입력

위치: excel_handler_improved.py

처리:
1. 파일 로드
2. 시트 선택
3. 블록별 처리
4. 저장

반환값:
- int: 입력한 셀 개수
"""
```

---

## 데이터 흐름

### 전체 흐름도
```
[원시 엑셀 파일]
        ↓
   load_file() ← xls_converter (필요시)
        ↓
  [DataFrame]
        ↓
  split_by_date()
        ↓
  [df_today] [df_yesterday]
        ↓           ↓
build_attendance_map()
        ↓           ↓
   [today_map] [yesterday_map]
        ↓           ↓
        └─────┬─────┘
              ↓
    prepare_attendance_sheet()
              ↓
    write_attendance_data()
              ↓
         [근태표]
```

### 데이터 변환 과정

#### 1단계: 원시 데이터 → DataFrame
```python
# 원시 데이터 (Excel)
'근무일자'  | '이름'  | '출근시간'           | '퇴근시간'
2025/12/22 | 김철수  | 2025/12/22 08:00    | 2025/12/22 18:00

# DataFrame
     '근무일자'            '이름'  '출근시간'           '퇴근시간'
0   2025-12-22 00:00:00  김철수  2025/12/22 08:00    2025/12/22 18:00
```

#### 2단계: DataFrame → 출퇴근 맵
```python
# DataFrame 처리
extract_time_str(row['출근시간']) → "08:00"
extract_time_str(row['퇴근시간']) → "18:00"

# 출퇴근 맵
{
    "김철수": {
        "출근시각": "08:00",
        "퇴근시각": "18:00",
        "출근일자": date(2025, 12, 22),
        "퇴근일자": date(2025, 12, 22)
    }
}
```

#### 3단계: 출퇴근 맵 → 근태표
```python
# 로직 판단
decide_attendance("김철수") 
→ ProcessResult(
    check_in="08:00",
    check_out="18:00",
    base_date=date(2025, 12, 22),
    pattern="day"
)

# 엑셀 셀에 쓰기
worksheet.cell(row=9, column=4).value = "08:00"  # 출근
worksheet.cell(row=9, column=5).value = "18:00"  # 퇴근
```

---

## 설정 변경 방법

### 1. 셀 범위 변경

**상황**: 근태표 양식이 변경되어 셀 위치가 바뀜

**수정 파일**: `config.py`

**예시**:
```python
# 기존
YEOJU_BLOCKS = [
    ("C9:C11", "D9:D11", "E9:E11"),  # 생산기술
]

# 변경 (예: 행이 한 줄 내려감)
YEOJU_BLOCKS = [
    ("C10:C12", "D10:D12", "E10:E12"),  # 생산기술
]
```

**주의사항**:
- 이름, 출근, 퇴근 범위는 행 수가 동일해야 함
- 범위 형식: "시작셀:끝셀" (예: "C9:C11")

---

### 2. 공휴일 추가

**상황**: 새로운 공휴일 또는 임시 휴무일 추가

**수정 파일**: `config.py`

**예시**:
```python
# 기존
HOLIDAYS_2025 = [
    "2025-01-01",  # 신정
    "2025-03-01",  # 삼일절
]

# 추가
HOLIDAYS_2025 = [
    "2025-01-01",  # 신정
    "2025-03-01",  # 삼일절
    "2025-12-24",  # 임시 휴무 추가
]
```

**형식**: `"YYYY-MM-DD"`

---

### 3. 컬럼명 변경

**상황**: 원시 데이터의 컬럼명이 변경됨

**수정 파일**: `config.py`

**예시**:
```python
# 기존
COL_DATE = "'근무일자'"
COL_NAME = "'이름'"

# 변경 (컬럼명이 '날짜', '성명'으로 변경)
COL_DATE = "'날짜'"
COL_NAME = "'성명'"
```

**주의사항**:
- 작은따옴표 포함해야 함: `"'컬럼명'"`
- 원시 데이터의 정확한 컬럼명 확인 필요

---

### 4. 새로운 부서 추가

**상황**: 새로운 부서가 생겨 근태표에 추가됨

**수정 파일**: `config.py`, `main_improved.py`

**1) config.py에 블록 추가**:
```python
YEOJU_BLOCKS = [
    # 기존 블록들...
    ("C30:C32", "D30:D32", "E30:E32"),  # 새 부서 추가
]

CLEAR_RANGES_YEOJU = [
    # 기존 범위들...
    "D30:E32", "G30:G32",  # 새 부서 범위 추가
]
```

**2) main_improved.py에서 사용**:
```python
# 자동으로 적용됨 (수정 불필요)
```

---

## 문제 해결 가이드

### 문제 1: 출근 시간 파싱 실패

**증상**:
```
[WARNING] '출근시간' 컬럼에 파싱 실패한 값: 25개
```

**원인**:
- 원시 데이터의 시간 형식이 예상과 다름
- 빈 값이나 텍스트가 섞여 있음

**해결**:
1. 원시 데이터 확인:
```python
df = pd.read_excel('12.22.xlsx')
print(df['출근시간'].unique())  # 실제 값 확인
```

2. `extract_time_str()` 함수 디버깅:
```python
# utils.py의 extract_time_str() 함수에 로그 추가
print(f"파싱 시도: {raw}, 타입: {type(raw)}")
```

3. 데이터 정제:
```python
# 원시 데이터에서 이상한 값 제거
df['출근시간'] = df['출근시간'].replace('', np.nan)
```

---

### 문제 2: 야간 근무자 처리 오류

**증상**:
- 야간 근무자가 주간 근무로 처리됨
- 출근/퇴근 날짜가 맞지 않음

**원인**:
- 날짜 분리 로직 오류
- 야간 근무 판별 조건 미충족

**해결**:
1. 로그 확인:
```python
# 로그에서 패턴 확인
[2025-12-19] 김철수, 출근=20:00, 퇴근=06:00
```

2. `is_night_shift()` 함수 확인:
```python
# attendance_logic.py
def is_night_shift(self, check_in_date, check_out_date):
    # 디버깅 로그 추가
    print(f"출근일: {check_in_date}, 퇴근일: {check_out_date}")
    print(f"차이: {(check_out_date - check_in_date).days}일")
```

3. 날짜 데이터 확인:
```python
# 출근일과 퇴근일이 올바르게 파싱되었는지 확인
info = today_map.get("김철수")
print(f"출근일자: {info['출근일자']}, 타입: {type(info['출근일자'])}")
print(f"퇴근일자: {info['퇴근일자']}, 타입: {type(info['퇴근일자'])}")
```

---

### 문제 3: 월요일 전일 데이터 없음

**증상**:
```
[WARNING] 전일(2025-12-21) 데이터가 없습니다.
[ERROR] 처리 실패
```

**원인**:
- 이전 근무일 검색 실패
- 공휴일 목록 누락

**해결**:
1. 공휴일 목록 확인:
```python
# config.py
HOLIDAYS_2025 = [
    "2025-12-21",  # 일요일은 자동 제외되므로 추가 불필요
    # 실제 공휴일만 추가
]
```

2. `find_previous_workday()` 디버깅:
```python
# data_processor_improved.py
def find_previous_workday(self, from_date, max_days=7):
    print(f"검색 시작: {from_date}")
    current = from_date - timedelta(days=1)
    
    for i in range(max_days):
        print(f"  체크: {current}, 근무일: {self.is_workday(current)}")
        if self.is_workday(current):
            return current
        current -= timedelta(days=1)
```

3. 검색 범위 확장:
```python
# 기본 7일 → 14일로 확장
prev_workday = self.find_previous_workday(self.base_date, max_days=14)
```

---

### 문제 4: NaT strftime 오류

**증상**:
```
[ERROR] NaTType does not support strftime
```

**원인**:
- NaT(Not a Time) 값에 strftime() 호출

**해결**:
- v2.4에서 이미 수정됨
- `logger.py`와 `utils.py`에 NaT 체크 있음

**확인**:
```python
# logger.py
if not pd.isna(base_date) and hasattr(base_date, "strftime"):
    date_str = base_date.strftime('%Y-%m-%d')  # ✅ 안전
```

---

### 문제 5: 중복 이름 처리

**증상**:
```
[WARNING] 중복된 이름 발견: 손윤숙
```

**원인**:
- 여주/SMC 근태표에 같은 이름이 있음
- 데이터 맵에서 나중 값으로 덮어씀

**해결 방법**:

**방법 1: 데이터 맵에 구분자 추가**
```python
# data_processor_improved.py
def build_attendance_map(self, df):
    # 부서 정보 추가
    for idx, row in df.iterrows():
        name = row[COL_NAME]
        dept = row.get("'조직2'", "")  # 부서 컬럼
        key = f"{name}_{dept}"  # 고유 키 생성
        
        attendance_map[key] = {
            "출근시각": ...,
            "퇴근시각": ...,
        }
```

**방법 2: 경고만 표시 (현재 방식)**
```python
# 로그만 출력하고 마지막 값 사용
if name in attendance_map:
    self.logger.warning(f"중복된 이름 발견: {name}")
```

---

## 확장 가이드

### 1. 새로운 근태표 추가

**상황**: 세종 사업장 근태표 추가

**단계**:

**1) config.py에 설정 추가**:
```python
# 세종 근태표 블록
SEJONG_BLOCKS = [
    ("C9:C15", "D9:D15", "E9:E15"),  # 부서1
    ("J9:J20", "K9:K20", "L9:L20"),  # 부서2
]

# 세종 지울 범위
CLEAR_RANGES_SEJONG = [
    "D9:E15", "G9:G15",
    "K9:L20", "N9:N20",
]
```

**2) main_improved.py에 FileConfig 추가**:
```python
# 세종 근태표 설정
sejong_config = FileConfig(
    raw_file=raw_file,
    attendance_file="세종 근태표.xlsx",
    sheet_name=sheet_name,
    blocks=SEJONG_BLOCKS,
    clear_ranges=CLEAR_RANGES_SEJONG,
    label="세종"
)

# 처리
processor.update_sheet(sejong_config)
```

---

### 2. 새로운 출퇴근 패턴 추가

**상황**: 교대 근무 패턴 추가 (예: 오후 2시 출근)

**단계**:

**1) attendance_logic.py에 패턴 판별 추가**:
```python
def is_afternoon_shift(self, check_in_time, check_in_date):
    """
    오후 근무 판별 (12시~18시 출근)
    """
    if not check_in_time or check_in_date is None:
        return False
    
    hour = parse_time_hour(check_in_time)
    return 12 <= hour < 18
```

**2) decide_attendance()에 케이스 추가**:
```python
def decide_attendance(self, name):
    # ...
    is_afternoon = self.is_afternoon_shift(cin_today, din_today)
    
    # 오후 근무 처리
    if is_afternoon:
        return ProcessResult(
            check_in=cin_today,
            check_out=cout_today or "",
            base_date=din_today,
            pattern="afternoon"
        )
```

---

### 3. 알림 기능 추가

**상황**: 처리 완료 시 메시지 전송

**단계**:

**1) 알림 모듈 생성** (`notification.py`):
```python
def send_notification(message):
    """
    알림 전송 (이메일, Slack 등)
    """
    try:
        # 이메일 전송
        import smtplib
        from email.mime.text import MIMEText
        
        msg = MIMEText(message)
        msg['Subject'] = '근태 입력 완료'
        msg['From'] = 'system@company.com'
        msg['To'] = 'admin@company.com'
        
        with smtplib.SMTP('smtp.company.com', 587) as server:
            server.send_message(msg)
            
    except Exception as e:
        print(f"알림 전송 실패: {e}")
```

**2) main_improved.py에서 호출**:
```python
from notification import send_notification

# 처리 완료 후
if success:
    send_notification(f"근태 입력 완료: {base_date}")
```

---

### 4. 데이터베이스 연동

**상황**: 원시 데이터를 DB에서 가져오기

**단계**:

**1) DB 연결 모듈 생성** (`db_connector.py`):
```python
import pymysql

def fetch_attendance_data(date):
    """
    DB에서 출퇴근 데이터 조회
    """
    conn = pymysql.connect(
        host='localhost',
        user='user',
        password='password',
        database='attendance'
    )
    
    query = """
        SELECT 근무일자, 이름, 출근시간, 퇴근시간
        FROM 출퇴근기록
        WHERE 근무일자 BETWEEN %s AND %s
    """
    
    df = pd.read_sql(query, conn, params=[date-7, date])
    conn.close()
    
    return df
```

**2) data_processor_improved.py에서 사용**:
```python
def load_file(self):
    # 파일 대신 DB 조회
    from db_connector import fetch_attendance_data
    
    df = fetch_attendance_data(self.base_date)
    return df
```

---

## 코딩 규칙

### 1. 네이밍 컨벤션
```python
# 클래스: PascalCase
class DataProcessor:
    pass

# 함수/변수: snake_case
def load_file():
    file_path = "..."

# 상수: UPPER_SNAKE_CASE
COL_DATE = "'근무일자'"

# Private: 언더스코어 접두사
def _internal_method():
    pass
```

### 2. 주석 스타일
```python
def function_name(param1, param2):
    """
    함수 설명
    
    Args:
        param1: 매개변수 1 설명
        param2: 매개변수 2 설명
    
    Returns:
        반환값 설명
    
    Raises:
        예외 설명
    """
    pass
```

### 3. 에러 처리
```python
# Good: 구체적인 예외 처리
try:
    result = process_data()
except FileNotFoundError:
    logger.error("파일을 찾을 수 없습니다")
except pd.errors.ParserError:
    logger.error("데이터 파싱 실패")
except Exception as e:
    logger.error(f"예상치 못한 오류: {e}")

# Bad: 모든 예외를 무시
try:
    result = process_data()
except:
    pass
```

### 4. 로깅 레벨
```python
logger.debug("변수 값: x=10")       # 디버깅용
logger.info("파일 로딩 완료")        # 일반 정보
logger.success("처리 완료")          # 성공
logger.warning("데이터 없음")        # 경고
logger.error("파일 없음")           # 오류
```

---

## 테스트 가이드

### 단위 테스트 예시

```python
import unittest
from attendance_logic import AttendanceLogic

class TestAttendanceLogic(unittest.TestCase):
    
    def setUp(self):
        """테스트 전 설정"""
        self.today_map = {
            "김철수": {
                "출근시각": "08:00",
                "퇴근시각": "18:00",
                "출근일자": date(2025, 12, 22),
                "퇴근일자": date(2025, 12, 22)
            }
        }
        self.yesterday_map = {}
        self.logic = AttendanceLogic(self.today_map, self.yesterday_map)
    
    def test_day_shift(self):
        """주간 근무 테스트"""
        result = self.logic.decide_attendance("김철수")
        
        self.assertEqual(result.check_in, "08:00")
        self.assertEqual(result.check_out, "18:00")
        self.assertEqual(result.pattern, "day")
    
    def test_absent(self):
        """결근 테스트"""
        result = self.logic.decide_attendance("홍길동")  # 없는 사람
        
        self.assertEqual(result.check_in, "")
        self.assertEqual(result.check_out, "")
        self.assertEqual(result.pattern, "absent")

if __name__ == '__main__':
    unittest.main()
```

---

## 버전 관리

### Git 사용 권장
```bash
# 초기화
git init
git add .
git commit -m "v2.4 초기 커밋"

# 브랜치 생성
git branch feature/new-pattern
git checkout feature/new-pattern

# 커밋
git add attendance_logic.py
git commit -m "오후 근무 패턴 추가"

# 병합
git checkout main
git merge feature/new-pattern
```

### 커밋 메시지 규칙
```
feat: 새 기능 추가
fix: 버그 수정
docs: 문서 수정
style: 코드 스타일 변경
refactor: 코드 리팩토링
test: 테스트 추가
chore: 빌드/설정 변경
```

---

## 연락처 및 지원

### 문의
- 시스템 개발: Claude AI
- 유지보수 담당자: [담당자 이름]

### 문서 버전
- 버전: 1.0
- 작성일: 2024-12-22
- 대상 프로그램: v2.4

---

## 부록

### A. 파일 크기 가이드
```
main_improved.py           ~15 KB
data_processor_improved.py ~25 KB
attendance_logic.py        ~8 KB
excel_handler_improved.py  ~15 KB
config.py                  ~5 KB
validators.py              ~20 KB
logger.py                  ~10 KB
utils.py                   ~3 KB
```

### B. 실행 시간 가이드
```
파일 로딩:        1-2초
데이터 처리:      1초
시트 준비:        2-3초
데이터 입력:      3-5초
---
총 실행 시간:     7-11초
```

### C. 메모리 사용량
```
DataFrame:        ~1-5 MB
출퇴근 맵:        ~100 KB
엑셀 워크북:      ~5-10 MB
---
총 메모리:        ~6-16 MB
```

---

**문서 끝**
