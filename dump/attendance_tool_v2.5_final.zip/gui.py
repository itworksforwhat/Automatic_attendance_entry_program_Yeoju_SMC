"""
attendance_tool/gui.py
GUI 인터페이스: Tkinter 기반 사용자 인터페이스
"""

import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime
from typing import Callable, Optional
from models import FileConfig


class AttendanceToolGUI:
    """근태 자동 입력 도구 GUI 클래스"""

    def __init__(self, on_run_callback: Optional[Callable] = None):
        """
        초기화

        Args:
            on_run_callback: 실행 버튼 클릭 시 호출할 함수
        """
        self.on_run_callback = on_run_callback

        # Tkinter 루트 윈도우 생성
        self.root = tk.Tk()
        self.root.title("근태 자동 입력 도구")

        # 입력 위젯들
        self.date_entry = None
        self.raw_entry = None
        self.yeoju_entry = None
        self.smc_entry = None
        self.logbox = None

        # UI 구성
        self._create_widgets()

    def _create_widgets(self):
        """UI 위젯 생성"""
        # === 기준 날짜 입력 ===
        tk.Label(self.root, text="기준 날짜 (YYYY-MM-DD)").grid(
            row=0, column=0, sticky="e", padx=5, pady=2
        )
        self.date_entry = tk.Entry(self.root, width=20)
        self.date_entry.grid(row=0, column=1, sticky="w", padx=5, pady=2)
        # 오늘 날짜를 기본값으로 설정
        self.date_entry.insert(0, datetime.today().strftime("%Y-%m-%d"))

        # === 파일 경로 입력 ===
        # 레이블
        tk.Label(self.root, text="출퇴근 원시 파일").grid(
            row=1, column=0, sticky="e", padx=5, pady=2
        )
        tk.Label(self.root, text="여주 근태 파일").grid(
            row=2, column=0, sticky="e", padx=5, pady=2
        )
        tk.Label(self.root, text="SMC 근태 파일").grid(
            row=3, column=0, sticky="e", padx=5, pady=2
        )

        # 입력 필드
        self.raw_entry = tk.Entry(self.root, width=60)
        self.yeoju_entry = tk.Entry(self.root, width=60)
        self.smc_entry = tk.Entry(self.root, width=60)

        self.raw_entry.grid(row=1, column=1, padx=5, pady=2)
        self.yeoju_entry.grid(row=2, column=1, padx=5, pady=2)
        self.smc_entry.grid(row=3, column=1, padx=5, pady=2)

        # 파일 찾기 버튼
        tk.Button(
            self.root, text="찾기",
            command=lambda: self._browse_file(self.raw_entry)
        ).grid(row=1, column=2, padx=5)

        tk.Button(
            self.root, text="찾기",
            command=lambda: self._browse_file(self.yeoju_entry)
        ).grid(row=2, column=2, padx=5)

        tk.Button(
            self.root, text="찾기",
            command=lambda: self._browse_file(self.smc_entry)
        ).grid(row=3, column=2, padx=5)

        # === 로그 창 ===
        tk.Label(self.root, text="로그").grid(
            row=4, column=0, sticky="nw", padx=5, pady=2
        )

        # 스크롤바 추가
        log_frame = tk.Frame(self.root)
        log_frame.grid(row=4, column=1, columnspan=2, padx=5, pady=5)

        scrollbar = tk.Scrollbar(log_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.logbox = tk.Text(log_frame, width=90, height=20,
                              yscrollcommand=scrollbar.set)
        self.logbox.pack(side=tk.LEFT, fill=tk.BOTH)
        scrollbar.config(command=self.logbox.yview)

        # === 실행 버튼 ===
        tk.Button(
            self.root, text="실행",
            command=self._on_run,
            bg="#4caf50", fg="white",
            font=("Arial", 10, "bold"),
            padx=20, pady=5
        ).grid(row=5, column=1, pady=10)

    def _browse_file(self, entry: tk.Entry):
        """
        파일 찾기 대화상자 열기

        Args:
            entry: 파일 경로를 입력받을 Entry 위젯
        """
        # 파일 선택 대화상자
        file_path = filedialog.askopenfilename(
            filetypes=[
                ("Excel files", "*.xls *.xlsx *.xlsm"),
                ("All files", "*.*")
            ]
        )

        # 파일이 선택되면 Entry에 경로 입력
        if file_path:
            entry.delete(0, tk.END)
            entry.insert(0, file_path)

    def _on_run(self):
        """실행 버튼 클릭 시 호출"""
        # 입력값 가져오기
        file_config = self.get_file_config()

        # 입력값 검증
        is_valid, error_msg = file_config.validate()
        if not is_valid:
            messagebox.showwarning("경고", error_msg)
            return

        # 콜백 함수가 등록되어 있으면 호출
        if self.on_run_callback:
            self.on_run_callback(file_config, self.logbox)

    def get_file_config(self) -> FileConfig:
        """
        입력된 파일 경로 정보를 FileConfig 객체로 반환

        Returns:
            FileConfig: 파일 설정 정보
        """
        return FileConfig(
            raw_file=self.raw_entry.get().strip(),
            yeoju_file=self.yeoju_entry.get().strip(),
            smc_file=self.smc_entry.get().strip(),
            base_date_str=self.date_entry.get().strip()
        )

    def clear_log(self):
        """로그 창 내용 지우기"""
        self.logbox.delete(1.0, tk.END)

    def run(self):
        """GUI 시작 (메인 루프 실행)"""
        self.root.mainloop()


def create_gui(on_run_callback: Optional[Callable] = None) -> AttendanceToolGUI:
    """
    GUI 생성 편의 함수

    Args:
        on_run_callback: 실행 버튼 클릭 시 호출할 함수

    Returns:
        AttendanceToolGUI: GUI 객체
    """
    return AttendanceToolGUI(on_run_callback)